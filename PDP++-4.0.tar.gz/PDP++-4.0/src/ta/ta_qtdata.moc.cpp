/****************************************************************************
** taiField meta object code from reading C++ file 'ta_qtdata.h'
**
** Created: Tue Jan 10 17:07:39 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ta_qtdata.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *taiField::className() const
{
    return "taiField";
}

QMetaObject *taiField::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiField( "taiField", &taiField::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiField::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiField", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiField::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiField", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiField::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiData::staticMetaObject();
    static const QUMethod slot_0 = {"selectionChanged", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "selectionChanged()", &slot_0, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiField", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiField.setMetaObject( metaObj );
    return metaObj;
}

void* taiField::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiField" ) )
	return this;
    return taiData::qt_cast( clname );
}

bool taiField::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: selectionChanged(); break;
    default:
	return taiData::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiField::qt_emit( int _id, QUObject* _o )
{
    return taiData::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiField::qt_property( int id, int f, QVariant* v)
{
    return taiData::qt_property( id, f, v);
}

bool taiField::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiIncrField::className() const
{
    return "taiIncrField";
}

QMetaObject *taiIncrField::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiIncrField( "taiIncrField", &taiIncrField::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiIncrField::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiIncrField", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiIncrField::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiIncrField", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiIncrField::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiData::staticMetaObject();
    static const QUMethod slot_0 = {"selectionChanged", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "selectionChanged()", &slot_0, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiIncrField", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiIncrField.setMetaObject( metaObj );
    return metaObj;
}

void* taiIncrField::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiIncrField" ) )
	return this;
    return taiData::qt_cast( clname );
}

bool taiIncrField::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: selectionChanged(); break;
    default:
	return taiData::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiIncrField::qt_emit( int _id, QUObject* _o )
{
    return taiData::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiIncrField::qt_property( int id, int f, QVariant* v)
{
    return taiData::qt_property( id, f, v);
}

bool taiIncrField::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiPlusToggle::className() const
{
    return "taiPlusToggle";
}

QMetaObject *taiPlusToggle::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiPlusToggle( "taiPlusToggle", &taiPlusToggle::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiPlusToggle::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiPlusToggle", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiPlusToggle::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiPlusToggle", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiPlusToggle::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiCompData::staticMetaObject();
    static const QUMethod slot_0 = {"Toggle_Callback", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "Toggle_Callback()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiPlusToggle", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiPlusToggle.setMetaObject( metaObj );
    return metaObj;
}

void* taiPlusToggle::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiPlusToggle" ) )
	return this;
    return taiCompData::qt_cast( clname );
}

bool taiPlusToggle::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Toggle_Callback(); break;
    default:
	return taiCompData::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiPlusToggle::qt_emit( int _id, QUObject* _o )
{
    return taiCompData::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiPlusToggle::qt_property( int id, int f, QVariant* v)
{
    return taiCompData::qt_property( id, f, v);
}

bool taiPlusToggle::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiComboBox::className() const
{
    return "taiComboBox";
}

QMetaObject *taiComboBox::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiComboBox( "taiComboBox", &taiComboBox::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiComboBox::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiComboBox", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiComboBox::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiComboBox", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiComboBox::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiData::staticMetaObject();
    static const QUParameter param_signal_0[] = {
	{ "itm", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"itemChanged", 1, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "itemChanged(int)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiComboBox", parentObject,
	0, 0,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiComboBox.setMetaObject( metaObj );
    return metaObj;
}

void* taiComboBox::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiComboBox" ) )
	return this;
    return taiData::qt_cast( clname );
}

// SIGNAL itemChanged
void taiComboBox::itemChanged( int t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 0, t0 );
}

bool taiComboBox::qt_invoke( int _id, QUObject* _o )
{
    return taiData::qt_invoke(_id,_o);
}

bool taiComboBox::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: itemChanged((int)static_QUType_int.get(_o+1)); break;
    default:
	return taiData::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool taiComboBox::qt_property( int id, int f, QVariant* v)
{
    return taiData::qt_property( id, f, v);
}

bool taiComboBox::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iBitCheckBox::className() const
{
    return "iBitCheckBox";
}

QMetaObject *iBitCheckBox::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iBitCheckBox( "iBitCheckBox", &iBitCheckBox::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iBitCheckBox::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iBitCheckBox", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iBitCheckBox::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iBitCheckBox", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iBitCheckBox::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iCheckBox::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "on", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"this_toggled", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "this_toggled(bool)", &slot_0, QMetaData::Public }
    };
    static const QUParameter param_signal_0[] = {
	{ "sender", &static_QUType_ptr, "iBitCheckBox", QUParameter::In },
	{ "on", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"toggledEx", 2, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "toggledEx(iBitCheckBox*,bool)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iBitCheckBox", parentObject,
	slot_tbl, 1,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iBitCheckBox.setMetaObject( metaObj );
    return metaObj;
}

void* iBitCheckBox::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iBitCheckBox" ) )
	return this;
    return iCheckBox::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL toggledEx
void iBitCheckBox::toggledEx( iBitCheckBox* t0, bool t1 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[3];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_bool.set(o+2,t1);
    activate_signal( clist, o );
}

bool iBitCheckBox::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: this_toggled((bool)static_QUType_bool.get(_o+1)); break;
    default:
	return iCheckBox::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iBitCheckBox::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: toggledEx((iBitCheckBox*)static_QUType_ptr.get(_o+1),(bool)static_QUType_bool.get(_o+2)); break;
    default:
	return iCheckBox::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool iBitCheckBox::qt_property( int id, int f, QVariant* v)
{
    return iCheckBox::qt_property( id, f, v);
}

bool iBitCheckBox::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiBitBox::className() const
{
    return "taiBitBox";
}

QMetaObject *taiBitBox::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiBitBox( "taiBitBox", &taiBitBox::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiBitBox::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiBitBox", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiBitBox::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiBitBox", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiBitBox::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiData::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "sender", &static_QUType_ptr, "iBitCheckBox", QUParameter::In },
	{ "on", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"bitCheck_toggled", 2, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "bitCheck_toggled(iBitCheckBox*,bool)", &slot_0, QMetaData::Public }
    };
    static const QUParameter param_signal_0[] = {
	{ "itm", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"itemChanged", 1, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "itemChanged(int)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiBitBox", parentObject,
	slot_tbl, 1,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiBitBox.setMetaObject( metaObj );
    return metaObj;
}

void* taiBitBox::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiBitBox" ) )
	return this;
    return taiData::qt_cast( clname );
}

// SIGNAL itemChanged
void taiBitBox::itemChanged( int t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 0, t0 );
}

bool taiBitBox::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: bitCheck_toggled((iBitCheckBox*)static_QUType_ptr.get(_o+1),(bool)static_QUType_bool.get(_o+2)); break;
    default:
	return taiData::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiBitBox::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: itemChanged((int)static_QUType_int.get(_o+1)); break;
    default:
	return taiData::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool taiBitBox::qt_property( int id, int f, QVariant* v)
{
    return taiData::qt_property( id, f, v);
}

bool taiBitBox::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiMenuEl::className() const
{
    return "taiMenuEl";
}

QMetaObject *taiMenuEl::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiMenuEl( "taiMenuEl", &taiMenuEl::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiMenuEl::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMenuEl", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiMenuEl::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMenuEl", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiMenuEl::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QObject::staticMetaObject();
    static const QUMethod slot_0 = {"Select", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "Select()", &slot_0, QMetaData::Public }
    };
    static const QUMethod signal_0 = {"Action", 0, 0 };
    static const QUParameter param_signal_1[] = {
	{ "sender", &static_QUType_ptr, "taiMenuEl", QUParameter::In }
    };
    static const QUMethod signal_1 = {"MenuAction", 1, param_signal_1 };
    static const QUParameter param_signal_2[] = {
	{ "param", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_2 = {"IntParamAction", 1, param_signal_2 };
    static const QUParameter param_signal_3[] = {
	{ "ptr", &static_QUType_ptr, "void", QUParameter::In }
    };
    static const QUMethod signal_3 = {"PtrParamAction", 1, param_signal_3 };
    static const QMetaData signal_tbl[] = {
	{ "Action()", &signal_0, QMetaData::Public },
	{ "MenuAction(taiMenuEl*)", &signal_1, QMetaData::Public },
	{ "IntParamAction(int)", &signal_2, QMetaData::Public },
	{ "PtrParamAction(void*)", &signal_3, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiMenuEl", parentObject,
	slot_tbl, 1,
	signal_tbl, 4,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiMenuEl.setMetaObject( metaObj );
    return metaObj;
}

void* taiMenuEl::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiMenuEl" ) )
	return this;
    return QObject::qt_cast( clname );
}

// SIGNAL Action
void taiMenuEl::Action()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

// SIGNAL MenuAction
void taiMenuEl::MenuAction( taiMenuEl* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 1 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL IntParamAction
void taiMenuEl::IntParamAction( int t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 2, t0 );
}

// SIGNAL PtrParamAction
void taiMenuEl::PtrParamAction( void* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 3 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

bool taiMenuEl::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Select(); break;
    default:
	return QObject::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiMenuEl::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: Action(); break;
    case 1: MenuAction((taiMenuEl*)static_QUType_ptr.get(_o+1)); break;
    case 2: IntParamAction((int)static_QUType_int.get(_o+1)); break;
    case 3: PtrParamAction((void*)static_QUType_ptr.get(_o+1)); break;
    default:
	return QObject::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool taiMenuEl::qt_property( int id, int f, QVariant* v)
{
    return QObject::qt_property( id, f, v);
}

bool taiMenuEl::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiMenu::className() const
{
    return "taiMenu";
}

QMetaObject *taiMenu::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiMenu( "taiMenu", &taiMenu::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiMenu::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMenu", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiMenu::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMenu", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiMenu::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiData::staticMetaObject();
    static const QUParameter param_signal_0[] = {
	{ "val", &static_QUType_charstar, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"labelChanged", 1, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "labelChanged(const char*)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiMenu", parentObject,
	0, 0,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiMenu.setMetaObject( metaObj );
    return metaObj;
}

void* taiMenu::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiMenu" ) )
	return this;
    return taiData::qt_cast( clname );
}

// SIGNAL labelChanged
void taiMenu::labelChanged( const char* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_charstar.set(o+1,t0);
    activate_signal( clist, o );
}

bool taiMenu::qt_invoke( int _id, QUObject* _o )
{
    return taiData::qt_invoke(_id,_o);
}

bool taiMenu::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: labelChanged((const char*)static_QUType_charstar.get(_o+1)); break;
    default:
	return taiData::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool taiMenu::qt_property( int id, int f, QVariant* v)
{
    return taiData::qt_property( id, f, v);
}

bool taiMenu::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iAction::className() const
{
    return "iAction";
}

QMetaObject *iAction::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iAction( "iAction", &iAction::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iAction::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iAction", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iAction::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iAction", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iAction::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QAction::staticMetaObject();
    static const QUMethod slot_0 = {"this_activated", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "this_activated()", &slot_0, QMetaData::Protected }
    };
    static const QUParameter param_signal_0[] = {
	{ "param", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"activated", 1, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "activated(int)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iAction", parentObject,
	slot_tbl, 1,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iAction.setMetaObject( metaObj );
    return metaObj;
}

void* iAction::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iAction" ) )
	return this;
    return QAction::qt_cast( clname );
}

// SIGNAL activated
void iAction::activated( int t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 0, t0 );
}

bool iAction::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: this_activated(); break;
    default:
	return QAction::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iAction::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: activated((int)static_QUType_int.get(_o+1)); break;
    default:
	return QAction::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool iAction::qt_property( int id, int f, QVariant* v)
{
    return QAction::qt_property( id, f, v);
}

bool iAction::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiObjChooser::className() const
{
    return "taiObjChooser";
}

QMetaObject *taiObjChooser::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiObjChooser( "taiObjChooser", &taiObjChooser::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiObjChooser::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiObjChooser", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiObjChooser::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiObjChooser", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiObjChooser::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUMethod slot_0 = {"accept", 0, 0 };
    static const QUMethod slot_1 = {"reject", 0, 0 };
    static const QUParameter param_slot_2[] = {
	{ "itm", &static_QUType_ptr, "QListBoxItem", QUParameter::In }
    };
    static const QUMethod slot_2 = {"browser_selectionChanged", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ "itm", &static_QUType_ptr, "QListBoxItem", QUParameter::In }
    };
    static const QUMethod slot_3 = {"browser_doubleClicked", 1, param_slot_3 };
    static const QUMethod slot_4 = {"DescendBrowser", 0, 0 };
    static const QUMethod slot_5 = {"AcceptEditor", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "accept()", &slot_0, QMetaData::Protected },
	{ "reject()", &slot_1, QMetaData::Protected },
	{ "browser_selectionChanged(QListBoxItem*)", &slot_2, QMetaData::Protected },
	{ "browser_doubleClicked(QListBoxItem*)", &slot_3, QMetaData::Protected },
	{ "DescendBrowser()", &slot_4, QMetaData::Protected },
	{ "AcceptEditor()", &slot_5, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiObjChooser", parentObject,
	slot_tbl, 6,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiObjChooser.setMetaObject( metaObj );
    return metaObj;
}

void* taiObjChooser::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiObjChooser" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool taiObjChooser::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: accept(); break;
    case 1: reject(); break;
    case 2: browser_selectionChanged((QListBoxItem*)static_QUType_ptr.get(_o+1)); break;
    case 3: browser_doubleClicked((QListBoxItem*)static_QUType_ptr.get(_o+1)); break;
    case 4: DescendBrowser(); break;
    case 5: AcceptEditor(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiObjChooser::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiObjChooser::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool taiObjChooser::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiFileButton::className() const
{
    return "taiFileButton";
}

QMetaObject *taiFileButton::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiFileButton( "taiFileButton", &taiFileButton::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiFileButton::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiFileButton", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiFileButton::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiFileButton", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiFileButton::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiData::staticMetaObject();
    static const QUMethod slot_0 = {"Open", 0, 0 };
    static const QUMethod slot_1 = {"Save", 0, 0 };
    static const QUMethod slot_2 = {"SaveAs", 0, 0 };
    static const QUMethod slot_3 = {"Append", 0, 0 };
    static const QUMethod slot_4 = {"Close", 0, 0 };
    static const QUMethod slot_5 = {"Edit", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "Open()", &slot_0, QMetaData::Public },
	{ "Save()", &slot_1, QMetaData::Public },
	{ "SaveAs()", &slot_2, QMetaData::Public },
	{ "Append()", &slot_3, QMetaData::Public },
	{ "Close()", &slot_4, QMetaData::Public },
	{ "Edit()", &slot_5, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiFileButton", parentObject,
	slot_tbl, 6,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiFileButton.setMetaObject( metaObj );
    return metaObj;
}

void* taiFileButton::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiFileButton" ) )
	return this;
    return taiData::qt_cast( clname );
}

bool taiFileButton::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Open(); break;
    case 1: Save(); break;
    case 2: SaveAs(); break;
    case 3: Append(); break;
    case 4: Close(); break;
    case 5: Edit(); break;
    default:
	return taiData::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiFileButton::qt_emit( int _id, QUObject* _o )
{
    return taiData::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiFileButton::qt_property( int id, int f, QVariant* v)
{
    return taiData::qt_property( id, f, v);
}

bool taiFileButton::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiToken::className() const
{
    return "taiToken";
}

QMetaObject *taiToken::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiToken( "taiToken", &taiToken::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiToken::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiToken", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiToken::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiToken", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiToken::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiElBase::staticMetaObject();
    static const QUMethod slot_0 = {"Edit", 0, 0 };
    static const QUMethod slot_1 = {"Chooser", 0, 0 };
    static const QUParameter param_slot_2[] = {
	{ "menu_el", &static_QUType_ptr, "taiMenuEl", QUParameter::In }
    };
    static const QUMethod slot_2 = {"ItemChosen", 1, param_slot_2 };
    static const QMetaData slot_tbl[] = {
	{ "Edit()", &slot_0, QMetaData::Protected },
	{ "Chooser()", &slot_1, QMetaData::Protected },
	{ "ItemChosen(taiMenuEl*)", &slot_2, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiToken", parentObject,
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiToken.setMetaObject( metaObj );
    return metaObj;
}

void* taiToken::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiToken" ) )
	return this;
    return taiElBase::qt_cast( clname );
}

bool taiToken::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Edit(); break;
    case 1: Chooser(); break;
    case 2: ItemChosen((taiMenuEl*)static_QUType_ptr.get(_o+1)); break;
    default:
	return taiElBase::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiToken::qt_emit( int _id, QUObject* _o )
{
    return taiElBase::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiToken::qt_property( int id, int f, QVariant* v)
{
    return taiElBase::qt_property( id, f, v);
}

bool taiToken::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiSubToken::className() const
{
    return "taiSubToken";
}

QMetaObject *taiSubToken::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiSubToken( "taiSubToken", &taiSubToken::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiSubToken::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiSubToken", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiSubToken::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiSubToken", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiSubToken::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiElBase::staticMetaObject();
    static const QUMethod slot_0 = {"Edit", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "Edit()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiSubToken", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiSubToken.setMetaObject( metaObj );
    return metaObj;
}

void* taiSubToken::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiSubToken" ) )
	return this;
    return taiElBase::qt_cast( clname );
}

bool taiSubToken::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Edit(); break;
    default:
	return taiElBase::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiSubToken::qt_emit( int _id, QUObject* _o )
{
    return taiElBase::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiSubToken::qt_property( int id, int f, QVariant* v)
{
    return taiElBase::qt_property( id, f, v);
}

bool taiSubToken::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiMethodData::className() const
{
    return "taiMethodData";
}

QMetaObject *taiMethodData::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiMethodData( "taiMethodData", &taiMethodData::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiMethodData::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMethodData", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiMethodData::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMethodData", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiMethodData::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiData::staticMetaObject();
    static const QUMethod slot_0 = {"CallFun", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "CallFun()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiMethodData", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiMethodData.setMetaObject( metaObj );
    return metaObj;
}

void* taiMethodData::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiMethodData" ) )
	return this;
    return taiData::qt_cast( clname );
}

bool taiMethodData::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: CallFun(); break;
    default:
	return taiData::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiMethodData::qt_emit( int _id, QUObject* _o )
{
    return taiData::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiMethodData::qt_property( int id, int f, QVariant* v)
{
    return taiData::qt_property( id, f, v);
}

bool taiMethodData::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiMethToggle::className() const
{
    return "taiMethToggle";
}

QMetaObject *taiMethToggle::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiMethToggle( "taiMethToggle", &taiMethToggle::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiMethToggle::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMethToggle", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiMethToggle::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMethToggle", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiMethToggle::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiMethodData::staticMetaObject();
    static const QUMethod slot_0 = {"CallFun", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "CallFun()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiMethToggle", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiMethToggle.setMetaObject( metaObj );
    return metaObj;
}

void* taiMethToggle::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiMethToggle" ) )
	return this;
    return taiMethodData::qt_cast( clname );
}

bool taiMethToggle::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: CallFun(); break;
    default:
	return taiMethodData::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiMethToggle::qt_emit( int _id, QUObject* _o )
{
    return taiMethodData::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiMethToggle::qt_property( int id, int f, QVariant* v)
{
    return taiMethodData::qt_property( id, f, v);
}

bool taiMethToggle::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
