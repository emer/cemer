/****************************************************************************
** taiMultiClipData meta object code from reading C++ file 'ta_qtclipdata.h'
**
** Created: Mon Jan 9 15:04:09 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ta_qtclipdata.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *taiMultiClipData::className() const
{
    return "taiMultiClipData";
}

QMetaObject *taiMultiClipData::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiMultiClipData( "taiMultiClipData", &taiMultiClipData::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiMultiClipData::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMultiClipData", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiMultiClipData::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMultiClipData", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiMultiClipData::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiClipData::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"taiMultiClipData", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiMultiClipData.setMetaObject( metaObj );
    return metaObj;
}

void* taiMultiClipData::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiMultiClipData" ) )
	return this;
    return taiClipData::qt_cast( clname );
}

bool taiMultiClipData::qt_invoke( int _id, QUObject* _o )
{
    return taiClipData::qt_invoke(_id,_o);
}

bool taiMultiClipData::qt_emit( int _id, QUObject* _o )
{
    return taiClipData::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiMultiClipData::qt_property( int id, int f, QVariant* v)
{
    return taiClipData::qt_property( id, f, v);
}

bool taiMultiClipData::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiMimeItem::className() const
{
    return "taiMimeItem";
}

QMetaObject *taiMimeItem::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiMimeItem( "taiMimeItem", &taiMimeItem::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiMimeItem::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMimeItem", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiMimeItem::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMimeItem", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiMimeItem::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QObject::staticMetaObject();
    static const QUMethod slot_0 = {"obj_destroyed", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "obj_destroyed()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiMimeItem", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiMimeItem.setMetaObject( metaObj );
    return metaObj;
}

void* taiMimeItem::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiMimeItem" ) )
	return this;
    return QObject::qt_cast( clname );
}

bool taiMimeItem::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: obj_destroyed(); break;
    default:
	return QObject::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiMimeItem::qt_emit( int _id, QUObject* _o )
{
    return QObject::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiMimeItem::qt_property( int id, int f, QVariant* v)
{
    return QObject::qt_property( id, f, v);
}

bool taiMimeItem::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
