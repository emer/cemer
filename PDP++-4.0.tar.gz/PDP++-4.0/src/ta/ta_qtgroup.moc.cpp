/****************************************************************************
** gpiListEls meta object code from reading C++ file 'ta_qtgroup.h'
**
** Created: Tue Jan 3 20:50:23 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ta_qtgroup.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *gpiListEls::className() const
{
    return "gpiListEls";
}

QMetaObject *gpiListEls::metaObj = 0;
static QMetaObjectCleanUp cleanUp_gpiListEls( "gpiListEls", &gpiListEls::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString gpiListEls::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "gpiListEls", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString gpiListEls::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "gpiListEls", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* gpiListEls::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiElBase::staticMetaObject();
    static const QUMethod slot_0 = {"Edit", 0, 0 };
    static const QUMethod slot_1 = {"Choose", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "Edit()", &slot_0, QMetaData::Public },
	{ "Choose()", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"gpiListEls", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_gpiListEls.setMetaObject( metaObj );
    return metaObj;
}

void* gpiListEls::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "gpiListEls" ) )
	return this;
    return taiElBase::qt_cast( clname );
}

bool gpiListEls::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Edit(); break;
    case 1: Choose(); break;
    default:
	return taiElBase::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool gpiListEls::qt_emit( int _id, QUObject* _o )
{
    return taiElBase::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool gpiListEls::qt_property( int id, int f, QVariant* v)
{
    return taiElBase::qt_property( id, f, v);
}

bool gpiListEls::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *gpiGroupEls::className() const
{
    return "gpiGroupEls";
}

QMetaObject *gpiGroupEls::metaObj = 0;
static QMetaObjectCleanUp cleanUp_gpiGroupEls( "gpiGroupEls", &gpiGroupEls::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString gpiGroupEls::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "gpiGroupEls", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString gpiGroupEls::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "gpiGroupEls", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* gpiGroupEls::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = gpiListEls::staticMetaObject();
    static const QUMethod slot_0 = {"ChooseGp", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "ChooseGp()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"gpiGroupEls", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_gpiGroupEls.setMetaObject( metaObj );
    return metaObj;
}

void* gpiGroupEls::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "gpiGroupEls" ) )
	return this;
    return gpiListEls::qt_cast( clname );
}

bool gpiGroupEls::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: ChooseGp(); break;
    default:
	return gpiListEls::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool gpiGroupEls::qt_emit( int _id, QUObject* _o )
{
    return gpiListEls::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool gpiGroupEls::qt_property( int id, int f, QVariant* v)
{
    return gpiListEls::qt_property( id, f, v);
}

bool gpiGroupEls::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *gpiSubGroups::className() const
{
    return "gpiSubGroups";
}

QMetaObject *gpiSubGroups::metaObj = 0;
static QMetaObjectCleanUp cleanUp_gpiSubGroups( "gpiSubGroups", &gpiSubGroups::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString gpiSubGroups::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "gpiSubGroups", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString gpiSubGroups::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "gpiSubGroups", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* gpiSubGroups::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiElBase::staticMetaObject();
    static const QUMethod slot_0 = {"Edit", 0, 0 };
    static const QUMethod slot_1 = {"Choose", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "Edit()", &slot_0, QMetaData::Public },
	{ "Choose()", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"gpiSubGroups", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_gpiSubGroups.setMetaObject( metaObj );
    return metaObj;
}

void* gpiSubGroups::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "gpiSubGroups" ) )
	return this;
    return taiElBase::qt_cast( clname );
}

bool gpiSubGroups::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Edit(); break;
    case 1: Choose(); break;
    default:
	return taiElBase::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool gpiSubGroups::qt_emit( int _id, QUObject* _o )
{
    return taiElBase::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool gpiSubGroups::qt_property( int id, int f, QVariant* v)
{
    return taiElBase::qt_property( id, f, v);
}

bool gpiSubGroups::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *gpiSelectEditDataHost::className() const
{
    return "gpiSelectEditDataHost";
}

QMetaObject *gpiSelectEditDataHost::metaObj = 0;
static QMetaObjectCleanUp cleanUp_gpiSelectEditDataHost( "gpiSelectEditDataHost", &gpiSelectEditDataHost::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString gpiSelectEditDataHost::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "gpiSelectEditDataHost", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString gpiSelectEditDataHost::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "gpiSelectEditDataHost", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* gpiSelectEditDataHost::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiEditDataHost::staticMetaObject();
    static const QUMethod slot_0 = {"DoRemoveSelEdit", 0, 0 };
    static const QUParameter param_slot_1[] = {
	{ "idx", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"mnuRemoveMember_select", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ "idx", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"mnuRemoveMethod_select", 1, param_slot_2 };
    static const QMetaData slot_tbl[] = {
	{ "DoRemoveSelEdit()", &slot_0, QMetaData::Protected },
	{ "mnuRemoveMember_select(int)", &slot_1, QMetaData::Protected },
	{ "mnuRemoveMethod_select(int)", &slot_2, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"gpiSelectEditDataHost", parentObject,
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_gpiSelectEditDataHost.setMetaObject( metaObj );
    return metaObj;
}

void* gpiSelectEditDataHost::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "gpiSelectEditDataHost" ) )
	return this;
    return taiEditDataHost::qt_cast( clname );
}

bool gpiSelectEditDataHost::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: DoRemoveSelEdit(); break;
    case 1: mnuRemoveMember_select((int)static_QUType_int.get(_o+1)); break;
    case 2: mnuRemoveMethod_select((int)static_QUType_int.get(_o+1)); break;
    default:
	return taiEditDataHost::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool gpiSelectEditDataHost::qt_emit( int _id, QUObject* _o )
{
    return taiEditDataHost::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool gpiSelectEditDataHost::qt_property( int id, int f, QVariant* v)
{
    return taiEditDataHost::qt_property( id, f, v);
}

bool gpiSelectEditDataHost::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
