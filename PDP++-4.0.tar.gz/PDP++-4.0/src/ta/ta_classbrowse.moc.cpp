/****************************************************************************
** iClassBrowser meta object code from reading C++ file 'ta_classbrowse.h'
**
** Created: Tue Jan 10 18:10:59 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ta_classbrowse.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iClassBrowser::className() const
{
    return "iClassBrowser";
}

QMetaObject *iClassBrowser::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iClassBrowser( "iClassBrowser", &iClassBrowser::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iClassBrowser::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iClassBrowser", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iClassBrowser::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iClassBrowser", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iClassBrowser::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iDataBrowserBase::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "mel", &static_QUType_ptr, "taiMenuEl", QUParameter::In }
    };
    static const QUMethod slot_0 = {"mnuNewBrowser", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "mnuNewBrowser(taiMenuEl*)", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iClassBrowser", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iClassBrowser.setMetaObject( metaObj );
    return metaObj;
}

void* iClassBrowser::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iClassBrowser" ) )
	return this;
    return iDataBrowserBase::qt_cast( clname );
}

bool iClassBrowser::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: mnuNewBrowser((taiMenuEl*)static_QUType_ptr.get(_o+1)); break;
    default:
	return iDataBrowserBase::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iClassBrowser::qt_emit( int _id, QUObject* _o )
{
    return iDataBrowserBase::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iClassBrowser::qt_property( int id, int f, QVariant* v)
{
    return iDataBrowserBase::qt_property( id, f, v);
}

bool iClassBrowser::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
