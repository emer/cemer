/****************************************************************************
** iContextLabel meta object code from reading C++ file 'ta_qtdialog.h'
**
** Created: Wed Jan 11 16:45:50 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ta_qtdialog.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iContextLabel::className() const
{
    return "iContextLabel";
}

QMetaObject *iContextLabel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iContextLabel( "iContextLabel", &iContextLabel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iContextLabel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iContextLabel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iContextLabel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iContextLabel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iContextLabel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QLabel::staticMetaObject();
    static const QUParameter param_signal_0[] = {
	{ "sender", &static_QUType_ptr, "iContextLabel", QUParameter::In },
	{ "e", &static_QUType_ptr, "QContextMenuEvent", QUParameter::In }
    };
    static const QUMethod signal_0 = {"contextMenuInvoked", 2, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "contextMenuInvoked(iContextLabel*,QContextMenuEvent*)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iContextLabel", parentObject,
	0, 0,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iContextLabel.setMetaObject( metaObj );
    return metaObj;
}

void* iContextLabel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iContextLabel" ) )
	return this;
    return QLabel::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL contextMenuInvoked
void iContextLabel::contextMenuInvoked( iContextLabel* t0, QContextMenuEvent* t1 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[3];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_ptr.set(o+2,t1);
    activate_signal( clist, o );
}

bool iContextLabel::qt_invoke( int _id, QUObject* _o )
{
    return QLabel::qt_invoke(_id,_o);
}

bool iContextLabel::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: contextMenuInvoked((iContextLabel*)static_QUType_ptr.get(_o+1),(QContextMenuEvent*)static_QUType_ptr.get(_o+2)); break;
    default:
	return QLabel::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool iContextLabel::qt_property( int id, int f, QVariant* v)
{
    return QLabel::qt_property( id, f, v);
}

bool iContextLabel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiChoiceDialog::className() const
{
    return "taiChoiceDialog";
}

QMetaObject *taiChoiceDialog::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiChoiceDialog( "taiChoiceDialog", &taiChoiceDialog::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiChoiceDialog::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiChoiceDialog", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiChoiceDialog::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiChoiceDialog", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiChoiceDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUMethod slot_0 = {"accept", 0, 0 };
    static const QUMethod slot_1 = {"reject", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "accept()", &slot_0, QMetaData::Protected },
	{ "reject()", &slot_1, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiChoiceDialog", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiChoiceDialog.setMetaObject( metaObj );
    return metaObj;
}

void* taiChoiceDialog::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiChoiceDialog" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool taiChoiceDialog::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: accept(); break;
    case 1: reject(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiChoiceDialog::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiChoiceDialog::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool taiChoiceDialog::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *Dialog::className() const
{
    return "Dialog";
}

QMetaObject *Dialog::metaObj = 0;
static QMetaObjectCleanUp cleanUp_Dialog( "Dialog", &Dialog::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString Dialog::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "Dialog", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString Dialog::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "Dialog", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* Dialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUMethod slot_0 = {"accept", 0, 0 };
    static const QUMethod slot_1 = {"reject", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "accept()", &slot_0, QMetaData::Protected },
	{ "reject()", &slot_1, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"Dialog", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_Dialog.setMetaObject( metaObj );
    return metaObj;
}

void* Dialog::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "Dialog" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool Dialog::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: accept(); break;
    case 1: reject(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool Dialog::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool Dialog::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool Dialog::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiDataHost::className() const
{
    return "taiDataHost";
}

QMetaObject *taiDataHost::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiDataHost( "taiDataHost", &taiDataHost::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiDataHost::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiDataHost", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiDataHost::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiDataHost", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiDataHost::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QObject::staticMetaObject();
    static const QUMethod slot_0 = {"Apply", 0, 0 };
    static const QUMethod slot_1 = {"Revert", 0, 0 };
    static const QUMethod slot_2 = {"Changed", 0, 0 };
    static const QUMethod slot_3 = {"BodyCleared", 0, 0 };
    static const QUMethod slot_4 = {"Ok", 0, 0 };
    static const QUMethod slot_5 = {"Cancel", 0, 0 };
    static const QUParameter param_slot_6[] = {
	{ "sender", &static_QUType_ptr, "iContextLabel", QUParameter::In },
	{ "e", &static_QUType_ptr, "QContextMenuEvent", QUParameter::In }
    };
    static const QUMethod slot_6 = {"label_contextMenuInvoked", 2, param_slot_6 };
    static const QMetaData slot_tbl[] = {
	{ "Apply()", &slot_0, QMetaData::Public },
	{ "Revert()", &slot_1, QMetaData::Public },
	{ "Changed()", &slot_2, QMetaData::Public },
	{ "BodyCleared()", &slot_3, QMetaData::Public },
	{ "Ok()", &slot_4, QMetaData::Public },
	{ "Cancel()", &slot_5, QMetaData::Public },
	{ "label_contextMenuInvoked(iContextLabel*,QContextMenuEvent*)", &slot_6, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiDataHost", parentObject,
	slot_tbl, 7,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiDataHost.setMetaObject( metaObj );
    return metaObj;
}

void* taiDataHost::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiDataHost" ) )
	return this;
    return QObject::qt_cast( clname );
}

bool taiDataHost::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Apply(); break;
    case 1: Revert(); break;
    case 2: Changed(); break;
    case 3: BodyCleared(); break;
    case 4: Ok(); break;
    case 5: Cancel(); break;
    case 6: label_contextMenuInvoked((iContextLabel*)static_QUType_ptr.get(_o+1),(QContextMenuEvent*)static_QUType_ptr.get(_o+2)); break;
    default:
	return QObject::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiDataHost::qt_emit( int _id, QUObject* _o )
{
    return QObject::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiDataHost::qt_property( int id, int f, QVariant* v)
{
    return QObject::qt_property( id, f, v);
}

bool taiDataHost::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiEditDataHost::className() const
{
    return "taiEditDataHost";
}

QMetaObject *taiEditDataHost::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiEditDataHost( "taiEditDataHost", &taiEditDataHost::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiEditDataHost::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiEditDataHost", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiEditDataHost::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiEditDataHost", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiEditDataHost::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiDataHost::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "sender", &static_QUType_ptr, "taiMenuEl", QUParameter::In }
    };
    static const QUMethod slot_0 = {"ShowChange", 1, param_slot_0 };
    static const QUMethod slot_1 = {"Cancel", 0, 0 };
    static const QUParameter param_slot_2[] = {
	{ "param", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"DoSelectForEdit", 1, param_slot_2 };
    static const QMetaData slot_tbl[] = {
	{ "ShowChange(taiMenuEl*)", &slot_0, QMetaData::Public },
	{ "Cancel()", &slot_1, QMetaData::Public },
	{ "DoSelectForEdit(int)", &slot_2, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiEditDataHost", parentObject,
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiEditDataHost.setMetaObject( metaObj );
    return metaObj;
}

void* taiEditDataHost::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiEditDataHost" ) )
	return this;
    return taiDataHost::qt_cast( clname );
}

bool taiEditDataHost::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: ShowChange((taiMenuEl*)static_QUType_ptr.get(_o+1)); break;
    case 1: Cancel(); break;
    case 2: DoSelectForEdit((int)static_QUType_int.get(_o+1)); break;
    default:
	return taiDataHost::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiEditDataHost::qt_emit( int _id, QUObject* _o )
{
    return taiDataHost::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiEditDataHost::qt_property( int id, int f, QVariant* v)
{
    return taiDataHost::qt_property( id, f, v);
}

bool taiEditDataHost::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
