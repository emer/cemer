/****************************************************************************
** taiData meta object code from reading C++ file 'ta_qtdata_def.h'
**
** Created: Tue Jan 10 17:07:39 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ta_qtdata_def.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *taiData::className() const
{
    return "taiData";
}

QMetaObject *taiData::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiData( "taiData", &taiData::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiData::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiData", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiData::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiData", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiData::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QObject::staticMetaObject();
    static const QUMethod slot_0 = {"repChanged", 0, 0 };
    static const QUParameter param_slot_1[] = {
	{ "obj", &static_QUType_ptr, "QObject", QUParameter::In }
    };
    static const QUMethod slot_1 = {"repDestroyed", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ "ea", &static_QUType_int, 0, QUParameter::InOut }
    };
    static const QUMethod slot_2 = {"this_GetEditActionsEnabled", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ "param", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_3 = {"this_EditAction", 1, param_slot_3 };
    static const QUMethod slot_4 = {"this_SetActionsEnabled", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "repChanged()", &slot_0, QMetaData::Protected },
	{ "repDestroyed(QObject*)", &slot_1, QMetaData::Protected },
	{ "this_GetEditActionsEnabled(int&)", &slot_2, QMetaData::Protected },
	{ "this_EditAction(int)", &slot_3, QMetaData::Protected },
	{ "this_SetActionsEnabled()", &slot_4, QMetaData::Protected }
    };
    static const QUParameter param_signal_0[] = {
	{ "value", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"settingHiBG", 1, param_signal_0 };
    static const QUMethod signal_1 = {"UpdateUi", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "settingHiBG(bool)", &signal_0, QMetaData::Public },
	{ "UpdateUi()", &signal_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiData", parentObject,
	slot_tbl, 5,
	signal_tbl, 2,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiData.setMetaObject( metaObj );
    return metaObj;
}

void* taiData::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiData" ) )
	return this;
    return QObject::qt_cast( clname );
}

// SIGNAL settingHiBG
void taiData::settingHiBG( bool t0 )
{
    activate_signal_bool( staticMetaObject()->signalOffset() + 0, t0 );
}

// SIGNAL UpdateUi
void taiData::UpdateUi()
{
    activate_signal( staticMetaObject()->signalOffset() + 1 );
}

bool taiData::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: repChanged(); break;
    case 1: repDestroyed((QObject*)static_QUType_ptr.get(_o+1)); break;
    case 2: this_GetEditActionsEnabled((int&)static_QUType_int.get(_o+1)); break;
    case 3: this_EditAction((int)static_QUType_int.get(_o+1)); break;
    case 4: this_SetActionsEnabled(); break;
    default:
	return QObject::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiData::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: settingHiBG((bool)static_QUType_bool.get(_o+1)); break;
    case 1: UpdateUi(); break;
    default:
	return QObject::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool taiData::qt_property( int id, int f, QVariant* v)
{
    return QObject::qt_property( id, f, v);
}

bool taiData::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *taiEditButton::className() const
{
    return "taiEditButton";
}

QMetaObject *taiEditButton::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiEditButton( "taiEditButton", &taiEditButton::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiEditButton::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiEditButton", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiEditButton::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiEditButton", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiEditButton::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiData::staticMetaObject();
    static const QUMethod slot_0 = {"Edit", 0, 0 };
    static const QUParameter param_slot_1[] = {
	{ "label", &static_QUType_charstar, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"setRepLabel", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "Edit()", &slot_0, QMetaData::Public },
	{ "setRepLabel(const char*)", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiEditButton", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiEditButton.setMetaObject( metaObj );
    return metaObj;
}

void* taiEditButton::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiEditButton" ) )
	return this;
    return taiData::qt_cast( clname );
}

bool taiEditButton::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Edit(); break;
    case 1: setRepLabel((const char*)static_QUType_charstar.get(_o+1)); break;
    default:
	return taiData::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiEditButton::qt_emit( int _id, QUObject* _o )
{
    return taiData::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiEditButton::qt_property( int id, int f, QVariant* v)
{
    return taiData::qt_property( id, f, v);
}

bool taiEditButton::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
