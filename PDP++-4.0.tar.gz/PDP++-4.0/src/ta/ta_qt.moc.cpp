/****************************************************************************
** taiMisc meta object code from reading C++ file 'ta_qt.h'
**
** Created: Tue Jan 10 18:10:59 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ta_qt.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *taiMisc::className() const
{
    return "taiMisc";
}

QMetaObject *taiMisc::metaObj = 0;
static QMetaObjectCleanUp cleanUp_taiMisc( "taiMisc", &taiMisc::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString taiMisc::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMisc", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString taiMisc::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "taiMisc", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* taiMisc::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QObject::staticMetaObject();
    static const QUMethod slot_0 = {"MainWindowDestroyed", 0, 0 };
    static const QUMethod slot_1 = {"LoadDialogDestroyed", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "MainWindowDestroyed()", &slot_0, QMetaData::Protected },
	{ "LoadDialogDestroyed()", &slot_1, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"taiMisc", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_taiMisc.setMetaObject( metaObj );
    return metaObj;
}

void* taiMisc::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "taiMisc" ) )
	return this;
    return QObject::qt_cast( clname );
}

bool taiMisc::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: MainWindowDestroyed(); break;
    case 1: LoadDialogDestroyed(); break;
    default:
	return QObject::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool taiMisc::qt_emit( int _id, QUObject* _o )
{
    return QObject::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool taiMisc::qt_property( int id, int f, QVariant* v)
{
    return QObject::qt_property( id, f, v);
}

bool taiMisc::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
