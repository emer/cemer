/****************************************************************************
** iDataBrowserBase meta object code from reading C++ file 'ta_qtbrowse.h'
**
** Created: Wed Jan 11 16:45:51 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ta_qtbrowse.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iDataBrowserBase::className() const
{
    return "iDataBrowserBase";
}

QMetaObject *iDataBrowserBase::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iDataBrowserBase( "iDataBrowserBase", &iDataBrowserBase::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iDataBrowserBase::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataBrowserBase", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iDataBrowserBase::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataBrowserBase", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iDataBrowserBase::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iTabDataViewer::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "mel", &static_QUType_ptr, "taiMenuEl", QUParameter::In }
    };
    static const QUMethod slot_0 = {"mnuNewBrowser", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "param", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"mnuBrowseNodeDrop", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"lvwDataTree_contextMenuRequested", 3, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_3 = {"lvwDataTree_selectionChanged", 1, param_slot_3 };
    static const QMetaData slot_tbl[] = {
	{ "mnuNewBrowser(taiMenuEl*)", &slot_0, QMetaData::Public },
	{ "mnuBrowseNodeDrop(int)", &slot_1, QMetaData::Public },
	{ "lvwDataTree_contextMenuRequested(QListViewItem*,const QPoint&,int)", &slot_2, QMetaData::Protected },
	{ "lvwDataTree_selectionChanged(QListViewItem*)", &slot_3, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"iDataBrowserBase", parentObject,
	slot_tbl, 4,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iDataBrowserBase.setMetaObject( metaObj );
    return metaObj;
}

void* iDataBrowserBase::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iDataBrowserBase" ) )
	return this;
    return iTabDataViewer::qt_cast( clname );
}

bool iDataBrowserBase::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: mnuNewBrowser((taiMenuEl*)static_QUType_ptr.get(_o+1)); break;
    case 1: mnuBrowseNodeDrop((int)static_QUType_int.get(_o+1)); break;
    case 2: lvwDataTree_contextMenuRequested((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 3: lvwDataTree_selectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    default:
	return iTabDataViewer::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iDataBrowserBase::qt_emit( int _id, QUObject* _o )
{
    return iTabDataViewer::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iDataBrowserBase::qt_property( int id, int f, QVariant* v)
{
    return iTabDataViewer::qt_property( id, f, v);
}

bool iDataBrowserBase::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iDataBrowser::className() const
{
    return "iDataBrowser";
}

QMetaObject *iDataBrowser::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iDataBrowser( "iDataBrowser", &iDataBrowser::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iDataBrowser::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataBrowser", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iDataBrowser::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataBrowser", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iDataBrowser::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iDataBrowserBase::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "mel", &static_QUType_ptr, "taiMenuEl", QUParameter::In }
    };
    static const QUMethod slot_0 = {"mnuNewBrowser", 1, param_slot_0 };
    static const QUMethod slot_1 = {"toolsClassBrowser", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "mnuNewBrowser(taiMenuEl*)", &slot_0, QMetaData::Public },
	{ "toolsClassBrowser()", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iDataBrowser", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iDataBrowser.setMetaObject( metaObj );
    return metaObj;
}

void* iDataBrowser::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iDataBrowser" ) )
	return this;
    return iDataBrowserBase::qt_cast( clname );
}

bool iDataBrowser::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: mnuNewBrowser((taiMenuEl*)static_QUType_ptr.get(_o+1)); break;
    case 1: toolsClassBrowser(); break;
    default:
	return iDataBrowserBase::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iDataBrowser::qt_emit( int _id, QUObject* _o )
{
    return iDataBrowserBase::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iDataBrowser::qt_property( int id, int f, QVariant* v)
{
    return iDataBrowserBase::qt_property( id, f, v);
}

bool iDataBrowser::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
