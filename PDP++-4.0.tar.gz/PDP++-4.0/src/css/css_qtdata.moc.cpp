/****************************************************************************
** cssiMethMenu meta object code from reading C++ file 'css_qtdata.h'
**
** Created: Tue Jan 10 17:08:08 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "css_qtdata.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *cssiMethMenu::className() const
{
    return "cssiMethMenu";
}

QMetaObject *cssiMethMenu::metaObj = 0;
static QMetaObjectCleanUp cleanUp_cssiMethMenu( "cssiMethMenu", &cssiMethMenu::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString cssiMethMenu::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "cssiMethMenu", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString cssiMethMenu::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "cssiMethMenu", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* cssiMethMenu::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiMethMenu::staticMetaObject();
    static const QUMethod slot_0 = {"CallFun", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "CallFun()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"cssiMethMenu", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_cssiMethMenu.setMetaObject( metaObj );
    return metaObj;
}

void* cssiMethMenu::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "cssiMethMenu" ) )
	return this;
    return taiMethMenu::qt_cast( clname );
}

bool cssiMethMenu::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: CallFun(); break;
    default:
	return taiMethMenu::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool cssiMethMenu::qt_emit( int _id, QUObject* _o )
{
    return taiMethMenu::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool cssiMethMenu::qt_property( int id, int f, QVariant* v)
{
    return taiMethMenu::qt_property( id, f, v);
}

bool cssiMethMenu::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
