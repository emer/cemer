/****************************************************************************
** cssiType_QObj meta object code from reading C++ file 'css_qttype.h'
**
** Created: Tue Jan 10 17:08:08 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "css_qttype.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *cssiType_QObj::className() const
{
    return "cssiType_QObj";
}

QMetaObject *cssiType_QObj::metaObj = 0;
static QMetaObjectCleanUp cleanUp_cssiType_QObj( "cssiType_QObj", &cssiType_QObj::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString cssiType_QObj::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "cssiType_QObj", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString cssiType_QObj::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "cssiType_QObj", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* cssiType_QObj::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QObject::staticMetaObject();
    static const QUMethod slot_0 = {"CallEdit", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "CallEdit()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"cssiType_QObj", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_cssiType_QObj.setMetaObject( metaObj );
    return metaObj;
}

void* cssiType_QObj::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "cssiType_QObj" ) )
	return this;
    return QObject::qt_cast( clname );
}

bool cssiType_QObj::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: CallEdit(); break;
    default:
	return QObject::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool cssiType_QObj::qt_emit( int _id, QUObject* _o )
{
    return QObject::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool cssiType_QObj::qt_property( int id, int f, QVariant* v)
{
    return QObject::qt_property( id, f, v);
}

bool cssiType_QObj::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
