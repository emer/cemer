/****************************************************************************
** iLineEdit meta object code from reading C++ file 'ilineedit.h'
**
** Created: Wed Jan 11 16:45:35 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ilineedit.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iLineEdit::className() const
{
    return "iLineEdit";
}

QMetaObject *iLineEdit::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iLineEdit( "iLineEdit", &iLineEdit::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iLineEdit::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iLineEdit", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iLineEdit::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iLineEdit", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iLineEdit::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QLineEdit::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "value", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"setHilight", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "value", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"setReadOnly", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "setHilight(bool)", &slot_0, QMetaData::Public },
	{ "setReadOnly(bool)", &slot_1, QMetaData::Public }
    };
    static const QUParameter param_signal_0[] = {
	{ "got_focus", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"focusChanged", 1, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "focusChanged(bool)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iLineEdit", parentObject,
	slot_tbl, 2,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iLineEdit.setMetaObject( metaObj );
    return metaObj;
}

void* iLineEdit::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iLineEdit" ) )
	return this;
    return QLineEdit::qt_cast( clname );
}

// SIGNAL focusChanged
void iLineEdit::focusChanged( bool t0 )
{
    activate_signal_bool( staticMetaObject()->signalOffset() + 0, t0 );
}

bool iLineEdit::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: setHilight((bool)static_QUType_bool.get(_o+1)); break;
    case 1: setReadOnly((bool)static_QUType_bool.get(_o+1)); break;
    default:
	return QLineEdit::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iLineEdit::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: focusChanged((bool)static_QUType_bool.get(_o+1)); break;
    default:
	return QLineEdit::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool iLineEdit::qt_property( int id, int f, QVariant* v)
{
    return QLineEdit::qt_property( id, f, v);
}

bool iLineEdit::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
