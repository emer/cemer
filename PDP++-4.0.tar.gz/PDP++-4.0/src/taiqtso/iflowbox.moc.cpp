/****************************************************************************
** iFlowBox meta object code from reading C++ file 'iflowbox.h'
**
** Created: Tue Jan 10 17:07:24 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "iflowbox.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#include <qvariant.h>
const char *iFlowBox::className() const
{
    return "iFlowBox";
}

QMetaObject *iFlowBox::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iFlowBox( "iFlowBox", &iFlowBox::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iFlowBox::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iFlowBox", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iFlowBox::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iFlowBox", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iFlowBox::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QFrame::staticMetaObject();
    static const QUMethod slot_0 = {"fixFocus", 0, 0 };
    static const QUParameter param_slot_1[] = {
	{ "b", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"setChildrenEnabled", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "fixFocus()", &slot_0, QMetaData::Private },
	{ "setChildrenEnabled(bool)", &slot_1, QMetaData::Private }
    };
#ifndef QT_NO_PROPERTIES
    static const QMetaProperty props_tbl[5] = {
 	{ "QString","title", 0x3000103, &iFlowBox::metaObj, 0, -1 },
	{ "Alignment","alignment", 0x010f, &iFlowBox::metaObj, 0, -1 },
	{ "Alignment","flowAlignment", 0x010f, &iFlowBox::metaObj, 0, -1 },
	{ "Orientation","orientation", 0x110f, &iFlowBox::metaObj, 0, -1 },
	{ "bool","flat", 0x12000103, &iFlowBox::metaObj, 0, -1 }
    };
#endif // QT_NO_PROPERTIES
    metaObj = QMetaObject::new_metaobject(
	"iFlowBox", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	props_tbl, 5,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iFlowBox.setMetaObject( metaObj );
    return metaObj;
}

void* iFlowBox::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iFlowBox" ) )
	return this;
    return QFrame::qt_cast( clname );
}

bool iFlowBox::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: fixFocus(); break;
    case 1: setChildrenEnabled((bool)static_QUType_bool.get(_o+1)); break;
    default:
	return QFrame::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iFlowBox::qt_emit( int _id, QUObject* _o )
{
    return QFrame::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iFlowBox::qt_property( int id, int f, QVariant* v)
{
    switch ( id - staticMetaObject()->propertyOffset() ) {
    case 0: switch( f ) {
	case 0: setTitle(v->asString()); break;
	case 1: *v = QVariant( this->title() ); break;
	case 3: case 4: case 5: break;
	default: return FALSE;
    } break;
    case 1: switch( f ) {
	case 0: setAlignment(v->asInt()); break;
	case 1: *v = QVariant( (int)this->alignment() ); break;
	case 3: case 4: case 5: break;
	default: return FALSE;
    } break;
    case 2: switch( f ) {
	case 0: setFlowAlignment(v->asInt()); break;
	case 1: *v = QVariant( (int)this->flowAlignment() ); break;
	case 3: case 4: case 5: break;
	default: return FALSE;
    } break;
    case 3: switch( f ) {
	case 0: setOrientation((Orientation&)v->asInt()); break;
	case 1: *v = QVariant( (int)this->orientation() ); break;
	case 4: case 5: break;
	default: return FALSE;
    } break;
    case 4: switch( f ) {
	case 0: setFlat(v->asBool()); break;
	case 1: *v = QVariant( this->isFlat(), 0 ); break;
	case 3: case 4: case 5: break;
	default: return FALSE;
    } break;
    default:
	return QFrame::qt_property( id, f, v );
    }
    return TRUE;
}

bool iFlowBox::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
