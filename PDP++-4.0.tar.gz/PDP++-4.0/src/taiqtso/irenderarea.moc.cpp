/****************************************************************************
** iRenderAreaWrapper meta object code from reading C++ file 'irenderarea.h'
**
** Created: Wed Jan 11 16:45:35 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "irenderarea.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iRenderAreaWrapper::className() const
{
    return "iRenderAreaWrapper";
}

QMetaObject *iRenderAreaWrapper::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iRenderAreaWrapper( "iRenderAreaWrapper", &iRenderAreaWrapper::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iRenderAreaWrapper::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iRenderAreaWrapper", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iRenderAreaWrapper::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iRenderAreaWrapper", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iRenderAreaWrapper::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iRenderAreaWrapper", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iRenderAreaWrapper.setMetaObject( metaObj );
    return metaObj;
}

void* iRenderAreaWrapper::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iRenderAreaWrapper" ) )
	return this;
    return QWidget::qt_cast( clname );
}

bool iRenderAreaWrapper::qt_invoke( int _id, QUObject* _o )
{
    return QWidget::qt_invoke(_id,_o);
}

bool iRenderAreaWrapper::qt_emit( int _id, QUObject* _o )
{
    return QWidget::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iRenderAreaWrapper::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool iRenderAreaWrapper::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
