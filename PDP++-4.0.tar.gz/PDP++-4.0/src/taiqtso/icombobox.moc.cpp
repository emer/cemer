/****************************************************************************
** iComboBox meta object code from reading C++ file 'icombobox.h'
**
** Created: Tue Jan 10 17:07:24 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "icombobox.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iComboBox::className() const
{
    return "iComboBox";
}

QMetaObject *iComboBox::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iComboBox( "iComboBox", &iComboBox::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iComboBox::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iComboBox", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iComboBox::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iComboBox", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iComboBox::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QComboBox::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "value", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"setHilight", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "setHilight(bool)", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iComboBox", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iComboBox.setMetaObject( metaObj );
    return metaObj;
}

void* iComboBox::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iComboBox" ) )
	return this;
    return QComboBox::qt_cast( clname );
}

bool iComboBox::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: setHilight((bool)static_QUType_bool.get(_o+1)); break;
    default:
	return QComboBox::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iComboBox::qt_emit( int _id, QUObject* _o )
{
    return QComboBox::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iComboBox::qt_property( int id, int f, QVariant* v)
{
    return QComboBox::qt_property( id, f, v);
}

bool iComboBox::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
