/****************************************************************************
** iSpinBox meta object code from reading C++ file 'ispinbox.h'
**
** Created: Mon Jan 9 15:03:56 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ispinbox.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iSpinBox::className() const
{
    return "iSpinBox";
}

QMetaObject *iSpinBox::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iSpinBox( "iSpinBox", &iSpinBox::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iSpinBox::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iSpinBox", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iSpinBox::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iSpinBox", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iSpinBox::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QSpinBox::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "value", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"setHilight", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "value", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"setReadOnly", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "setHilight(bool)", &slot_0, QMetaData::Public },
	{ "setReadOnly(bool)", &slot_1, QMetaData::Public }
    };
    static const QUParameter param_signal_0[] = {
	{ "got_focus", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"focusChanged", 1, param_signal_0 };
    static const QUMethod signal_1 = {"selectionChanged", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "focusChanged(bool)", &signal_0, QMetaData::Public },
	{ "selectionChanged()", &signal_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iSpinBox", parentObject,
	slot_tbl, 2,
	signal_tbl, 2,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iSpinBox.setMetaObject( metaObj );
    return metaObj;
}

void* iSpinBox::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iSpinBox" ) )
	return this;
    return QSpinBox::qt_cast( clname );
}

// SIGNAL focusChanged
void iSpinBox::focusChanged( bool t0 )
{
    activate_signal_bool( staticMetaObject()->signalOffset() + 0, t0 );
}

// SIGNAL selectionChanged
void iSpinBox::selectionChanged()
{
    activate_signal( staticMetaObject()->signalOffset() + 1 );
}

bool iSpinBox::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: setHilight((bool)static_QUType_bool.get(_o+1)); break;
    case 1: setReadOnly((bool)static_QUType_bool.get(_o+1)); break;
    default:
	return QSpinBox::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iSpinBox::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: focusChanged((bool)static_QUType_bool.get(_o+1)); break;
    case 1: selectionChanged(); break;
    default:
	return QSpinBox::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool iSpinBox::qt_property( int id, int f, QVariant* v)
{
    return QSpinBox::qt_property( id, f, v);
}

bool iSpinBox::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
