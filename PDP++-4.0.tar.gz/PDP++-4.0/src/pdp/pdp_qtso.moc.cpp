/****************************************************************************
** ProcessDialog meta object code from reading C++ file 'pdp_qtso.h'
**
** Created: Tue Jan 3 20:51:13 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "pdp_qtso.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *ProcessDialog::className() const
{
    return "ProcessDialog";
}

QMetaObject *ProcessDialog::metaObj = 0;
static QMetaObjectCleanUp cleanUp_ProcessDialog( "ProcessDialog", &ProcessDialog::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString ProcessDialog::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ProcessDialog", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString ProcessDialog::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ProcessDialog", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* ProcessDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taiEditDataHost::staticMetaObject();
    static const QUMethod slot_0 = {"Ok", 0, 0 };
    static const QUMethod slot_1 = {"Cancel", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "Ok()", &slot_0, QMetaData::Public },
	{ "Cancel()", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"ProcessDialog", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_ProcessDialog.setMetaObject( metaObj );
    return metaObj;
}

void* ProcessDialog::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "ProcessDialog" ) )
	return this;
    return taiEditDataHost::qt_cast( clname );
}

bool ProcessDialog::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: Ok(); break;
    case 1: Cancel(); break;
    default:
	return taiEditDataHost::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool ProcessDialog::qt_emit( int _id, QUObject* _o )
{
    return taiEditDataHost::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool ProcessDialog::qt_property( int id, int f, QVariant* v)
{
    return taiEditDataHost::qt_property( id, f, v);
}

bool ProcessDialog::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
