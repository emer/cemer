/****************************************************************************
** LogViewAdapter meta object code from reading C++ file 'pdplog_qtso.h'
**
** Created: Tue Jan 3 20:51:13 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "pdplog_qtso.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *LogViewAdapter::className() const
{
    return "LogViewAdapter";
}

QMetaObject *LogViewAdapter::metaObj = 0;
static QMetaObjectCleanUp cleanUp_LogViewAdapter( "LogViewAdapter", &LogViewAdapter::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString LogViewAdapter::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "LogViewAdapter", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString LogViewAdapter::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "LogViewAdapter", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* LogViewAdapter::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taBaseAdapter::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "sels", &static_QUType_ptr, "ISelectable_PtrList", QUParameter::InOut }
    };
    static const QUMethod slot_0 = {"viewWin_selectionChanged", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "viewWin_selectionChanged(ISelectable_PtrList&)", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"LogViewAdapter", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_LogViewAdapter.setMetaObject( metaObj );
    return metaObj;
}

void* LogViewAdapter::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "LogViewAdapter" ) )
	return this;
    return taBaseAdapter::qt_cast( clname );
}

bool LogViewAdapter::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: viewWin_selectionChanged((ISelectable_PtrList&)*((ISelectable_PtrList*)static_QUType_ptr.get(_o+1))); break;
    default:
	return taBaseAdapter::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool LogViewAdapter::qt_emit( int _id, QUObject* _o )
{
    return taBaseAdapter::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool LogViewAdapter::qt_property( int id, int f, QVariant* v)
{
    return taBaseAdapter::qt_property( id, f, v);
}

bool LogViewAdapter::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *GridLogViewAdapter::className() const
{
    return "GridLogViewAdapter";
}

QMetaObject *GridLogViewAdapter::metaObj = 0;
static QMetaObjectCleanUp cleanUp_GridLogViewAdapter( "GridLogViewAdapter", &GridLogViewAdapter::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString GridLogViewAdapter::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "GridLogViewAdapter", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString GridLogViewAdapter::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "GridLogViewAdapter", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* GridLogViewAdapter::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = LogViewAdapter::staticMetaObject();
    static const QUMethod slot_0 = {"ColorBar_execute", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "ColorBar_execute()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"GridLogViewAdapter", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_GridLogViewAdapter.setMetaObject( metaObj );
    return metaObj;
}

void* GridLogViewAdapter::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "GridLogViewAdapter" ) )
	return this;
    return LogViewAdapter::qt_cast( clname );
}

bool GridLogViewAdapter::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: ColorBar_execute(); break;
    default:
	return LogViewAdapter::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool GridLogViewAdapter::qt_emit( int _id, QUObject* _o )
{
    return LogViewAdapter::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool GridLogViewAdapter::qt_property( int id, int f, QVariant* v)
{
    return LogViewAdapter::qt_property( id, f, v);
}

bool GridLogViewAdapter::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iLogView_Panel::className() const
{
    return "iLogView_Panel";
}

QMetaObject *iLogView_Panel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iLogView_Panel( "iLogView_Panel", &iLogView_Panel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iLogView_Panel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iLogView_Panel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iLogView_Panel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iLogView_Panel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iLogView_Panel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iViewPanelFrame::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "id", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"buttonClicked", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "on", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"chkDisplay_toggled", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "buttonClicked(int)", &slot_0, QMetaData::Protected },
	{ "chkDisplay_toggled(bool)", &slot_1, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"iLogView_Panel", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iLogView_Panel.setMetaObject( metaObj );
    return metaObj;
}

void* iLogView_Panel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iLogView_Panel" ) )
	return this;
    return iViewPanelFrame::qt_cast( clname );
}

bool iLogView_Panel::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: buttonClicked((int)static_QUType_int.get(_o+1)); break;
    case 1: chkDisplay_toggled((bool)static_QUType_bool.get(_o+1)); break;
    default:
	return iViewPanelFrame::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iLogView_Panel::qt_emit( int _id, QUObject* _o )
{
    return iViewPanelFrame::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iLogView_Panel::qt_property( int id, int f, QVariant* v)
{
    return iViewPanelFrame::qt_property( id, f, v);
}

bool iLogView_Panel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iGridLogViewBase_Panel::className() const
{
    return "iGridLogViewBase_Panel";
}

QMetaObject *iGridLogViewBase_Panel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iGridLogViewBase_Panel( "iGridLogViewBase_Panel", &iGridLogViewBase_Panel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iGridLogViewBase_Panel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGridLogViewBase_Panel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iGridLogViewBase_Panel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGridLogViewBase_Panel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iGridLogViewBase_Panel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iLogView_Panel::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "value", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"horScrBar_valueChanged", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "value", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"verScrBar_valueChanged", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "horScrBar_valueChanged(int)", &slot_0, QMetaData::Public },
	{ "verScrBar_valueChanged(int)", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iGridLogViewBase_Panel", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iGridLogViewBase_Panel.setMetaObject( metaObj );
    return metaObj;
}

void* iGridLogViewBase_Panel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iGridLogViewBase_Panel" ) )
	return this;
    return iLogView_Panel::qt_cast( clname );
}

bool iGridLogViewBase_Panel::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: horScrBar_valueChanged((int)static_QUType_int.get(_o+1)); break;
    case 1: verScrBar_valueChanged((int)static_QUType_int.get(_o+1)); break;
    default:
	return iLogView_Panel::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iGridLogViewBase_Panel::qt_emit( int _id, QUObject* _o )
{
    return iLogView_Panel::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iGridLogViewBase_Panel::qt_property( int id, int f, QVariant* v)
{
    return iLogView_Panel::qt_property( id, f, v);
}

bool iGridLogViewBase_Panel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iTextLogView_Panel::className() const
{
    return "iTextLogView_Panel";
}

QMetaObject *iTextLogView_Panel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iTextLogView_Panel( "iTextLogView_Panel", &iTextLogView_Panel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iTextLogView_Panel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTextLogView_Panel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iTextLogView_Panel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTextLogView_Panel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iTextLogView_Panel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iGridLogViewBase_Panel::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iTextLogView_Panel", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iTextLogView_Panel.setMetaObject( metaObj );
    return metaObj;
}

void* iTextLogView_Panel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iTextLogView_Panel" ) )
	return this;
    return iGridLogViewBase_Panel::qt_cast( clname );
}

bool iTextLogView_Panel::qt_invoke( int _id, QUObject* _o )
{
    return iGridLogViewBase_Panel::qt_invoke(_id,_o);
}

bool iTextLogView_Panel::qt_emit( int _id, QUObject* _o )
{
    return iGridLogViewBase_Panel::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iTextLogView_Panel::qt_property( int id, int f, QVariant* v)
{
    return iGridLogViewBase_Panel::qt_property( id, f, v);
}

bool iTextLogView_Panel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iNetLogView_Panel::className() const
{
    return "iNetLogView_Panel";
}

QMetaObject *iNetLogView_Panel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iNetLogView_Panel( "iNetLogView_Panel", &iNetLogView_Panel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iNetLogView_Panel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iNetLogView_Panel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iNetLogView_Panel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iNetLogView_Panel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iNetLogView_Panel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iLogView_Panel::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iNetLogView_Panel", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iNetLogView_Panel.setMetaObject( metaObj );
    return metaObj;
}

void* iNetLogView_Panel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iNetLogView_Panel" ) )
	return this;
    return iLogView_Panel::qt_cast( clname );
}

bool iNetLogView_Panel::qt_invoke( int _id, QUObject* _o )
{
    return iLogView_Panel::qt_invoke(_id,_o);
}

bool iNetLogView_Panel::qt_emit( int _id, QUObject* _o )
{
    return iLogView_Panel::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iNetLogView_Panel::qt_property( int id, int f, QVariant* v)
{
    return iLogView_Panel::qt_property( id, f, v);
}

bool iNetLogView_Panel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iGridLogView_Panel::className() const
{
    return "iGridLogView_Panel";
}

QMetaObject *iGridLogView_Panel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iGridLogView_Panel( "iGridLogView_Panel", &iGridLogView_Panel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iGridLogView_Panel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGridLogView_Panel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iGridLogView_Panel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGridLogView_Panel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iGridLogView_Panel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iLogView_Panel::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "on", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"chkAuto_toggled", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "on", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"chkHeaders_toggled", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "chkAuto_toggled(bool)", &slot_0, QMetaData::Protected },
	{ "chkHeaders_toggled(bool)", &slot_1, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"iGridLogView_Panel", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iGridLogView_Panel.setMetaObject( metaObj );
    return metaObj;
}

void* iGridLogView_Panel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iGridLogView_Panel" ) )
	return this;
    return iLogView_Panel::qt_cast( clname );
}

bool iGridLogView_Panel::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: chkAuto_toggled((bool)static_QUType_bool.get(_o+1)); break;
    case 1: chkHeaders_toggled((bool)static_QUType_bool.get(_o+1)); break;
    default:
	return iLogView_Panel::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iGridLogView_Panel::qt_emit( int _id, QUObject* _o )
{
    return iLogView_Panel::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iGridLogView_Panel::qt_property( int id, int f, QVariant* v)
{
    return iLogView_Panel::qt_property( id, f, v);
}

bool iGridLogView_Panel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iGraphLogView_Panel::className() const
{
    return "iGraphLogView_Panel";
}

QMetaObject *iGraphLogView_Panel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iGraphLogView_Panel( "iGraphLogView_Panel", &iGraphLogView_Panel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iGraphLogView_Panel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGraphLogView_Panel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iGraphLogView_Panel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGraphLogView_Panel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iGraphLogView_Panel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iLogView_Panel::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iGraphLogView_Panel", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iGraphLogView_Panel.setMetaObject( metaObj );
    return metaObj;
}

void* iGraphLogView_Panel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iGraphLogView_Panel" ) )
	return this;
    return iLogView_Panel::qt_cast( clname );
}

bool iGraphLogView_Panel::qt_invoke( int _id, QUObject* _o )
{
    return iLogView_Panel::qt_invoke(_id,_o);
}

bool iGraphLogView_Panel::qt_emit( int _id, QUObject* _o )
{
    return iLogView_Panel::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iGraphLogView_Panel::qt_property( int id, int f, QVariant* v)
{
    return iLogView_Panel::qt_property( id, f, v);
}

bool iGraphLogView_Panel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
