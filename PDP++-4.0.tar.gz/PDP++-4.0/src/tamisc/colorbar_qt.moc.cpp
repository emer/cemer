/****************************************************************************
** Bar meta object code from reading C++ file 'colorbar_qt.h'
**
** Created: Wed Jan 11 16:46:24 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "colorbar_qt.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *Bar::className() const
{
    return "Bar";
}

QMetaObject *Bar::metaObj = 0;
static QMetaObjectCleanUp cleanUp_Bar( "Bar", &Bar::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString Bar::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "Bar", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString Bar::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "Bar", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* Bar::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"Bar", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_Bar.setMetaObject( metaObj );
    return metaObj;
}

void* Bar::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "Bar" ) )
	return this;
    return QWidget::qt_cast( clname );
}

bool Bar::qt_invoke( int _id, QUObject* _o )
{
    return QWidget::qt_invoke(_id,_o);
}

bool Bar::qt_emit( int _id, QUObject* _o )
{
    return QWidget::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool Bar::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool Bar::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *HCBar::className() const
{
    return "HCBar";
}

QMetaObject *HCBar::metaObj = 0;
static QMetaObjectCleanUp cleanUp_HCBar( "HCBar", &HCBar::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString HCBar::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "HCBar", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString HCBar::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "HCBar", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* HCBar::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = Bar::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"HCBar", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_HCBar.setMetaObject( metaObj );
    return metaObj;
}

void* HCBar::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "HCBar" ) )
	return this;
    return Bar::qt_cast( clname );
}

bool HCBar::qt_invoke( int _id, QUObject* _o )
{
    return Bar::qt_invoke(_id,_o);
}

bool HCBar::qt_emit( int _id, QUObject* _o )
{
    return Bar::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool HCBar::qt_property( int id, int f, QVariant* v)
{
    return Bar::qt_property( id, f, v);
}

bool HCBar::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *VCBar::className() const
{
    return "VCBar";
}

QMetaObject *VCBar::metaObj = 0;
static QMetaObjectCleanUp cleanUp_VCBar( "VCBar", &VCBar::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString VCBar::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCBar", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString VCBar::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCBar", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* VCBar::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = Bar::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"VCBar", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_VCBar.setMetaObject( metaObj );
    return metaObj;
}

void* VCBar::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "VCBar" ) )
	return this;
    return Bar::qt_cast( clname );
}

bool VCBar::qt_invoke( int _id, QUObject* _o )
{
    return Bar::qt_invoke(_id,_o);
}

bool VCBar::qt_emit( int _id, QUObject* _o )
{
    return Bar::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool VCBar::qt_property( int id, int f, QVariant* v)
{
    return Bar::qt_property( id, f, v);
}

bool VCBar::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *ColorPad::className() const
{
    return "ColorPad";
}

QMetaObject *ColorPad::metaObj = 0;
static QMetaObjectCleanUp cleanUp_ColorPad( "ColorPad", &ColorPad::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString ColorPad::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ColorPad", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString ColorPad::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ColorPad", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* ColorPad::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"ColorPad", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_ColorPad.setMetaObject( metaObj );
    return metaObj;
}

void* ColorPad::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "ColorPad" ) )
	return this;
    return QWidget::qt_cast( clname );
}

bool ColorPad::qt_invoke( int _id, QUObject* _o )
{
    return QWidget::qt_invoke(_id,_o);
}

bool ColorPad::qt_emit( int _id, QUObject* _o )
{
    return QWidget::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool ColorPad::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool ColorPad::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *ScaleBar::className() const
{
    return "ScaleBar";
}

QMetaObject *ScaleBar::metaObj = 0;
static QMetaObjectCleanUp cleanUp_ScaleBar( "ScaleBar", &ScaleBar::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString ScaleBar::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ScaleBar", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString ScaleBar::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ScaleBar", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* ScaleBar::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUMethod slot_0 = {"editor_accept", 0, 0 };
    static const QUMethod slot_1 = {"Incr_Range", 0, 0 };
    static const QUMethod slot_2 = {"Decr_Range", 0, 0 };
    static const QUMethod slot_3 = {"Incr_Min", 0, 0 };
    static const QUMethod slot_4 = {"Incr_Max", 0, 0 };
    static const QUMethod slot_5 = {"Decr_Min", 0, 0 };
    static const QUMethod slot_6 = {"Decr_Max", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "editor_accept()", &slot_0, QMetaData::Public },
	{ "Incr_Range()", &slot_1, QMetaData::Public },
	{ "Decr_Range()", &slot_2, QMetaData::Public },
	{ "Incr_Min()", &slot_3, QMetaData::Public },
	{ "Incr_Max()", &slot_4, QMetaData::Public },
	{ "Decr_Min()", &slot_5, QMetaData::Public },
	{ "Decr_Max()", &slot_6, QMetaData::Public }
    };
    static const QUMethod signal_0 = {"scaleValueChanged", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "scaleValueChanged()", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"ScaleBar", parentObject,
	slot_tbl, 7,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_ScaleBar.setMetaObject( metaObj );
    return metaObj;
}

void* ScaleBar::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "ScaleBar" ) )
	return this;
    return QWidget::qt_cast( clname );
}

// SIGNAL scaleValueChanged
void ScaleBar::scaleValueChanged()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

bool ScaleBar::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: editor_accept(); break;
    case 1: Incr_Range(); break;
    case 2: Decr_Range(); break;
    case 3: Incr_Min(); break;
    case 4: Incr_Max(); break;
    case 5: Decr_Min(); break;
    case 6: Decr_Max(); break;
    default:
	return QWidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool ScaleBar::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: scaleValueChanged(); break;
    default:
	return QWidget::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool ScaleBar::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool ScaleBar::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *HCScaleBar::className() const
{
    return "HCScaleBar";
}

QMetaObject *HCScaleBar::metaObj = 0;
static QMetaObjectCleanUp cleanUp_HCScaleBar( "HCScaleBar", &HCScaleBar::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString HCScaleBar::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "HCScaleBar", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString HCScaleBar::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "HCScaleBar", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* HCScaleBar::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = ScaleBar::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"HCScaleBar", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_HCScaleBar.setMetaObject( metaObj );
    return metaObj;
}

void* HCScaleBar::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "HCScaleBar" ) )
	return this;
    return ScaleBar::qt_cast( clname );
}

bool HCScaleBar::qt_invoke( int _id, QUObject* _o )
{
    return ScaleBar::qt_invoke(_id,_o);
}

bool HCScaleBar::qt_emit( int _id, QUObject* _o )
{
    return ScaleBar::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool HCScaleBar::qt_property( int id, int f, QVariant* v)
{
    return ScaleBar::qt_property( id, f, v);
}

bool HCScaleBar::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *VCScaleBar::className() const
{
    return "VCScaleBar";
}

QMetaObject *VCScaleBar::metaObj = 0;
static QMetaObjectCleanUp cleanUp_VCScaleBar( "VCScaleBar", &VCScaleBar::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString VCScaleBar::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCScaleBar", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString VCScaleBar::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCScaleBar", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* VCScaleBar::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = ScaleBar::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"VCScaleBar", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_VCScaleBar.setMetaObject( metaObj );
    return metaObj;
}

void* VCScaleBar::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "VCScaleBar" ) )
	return this;
    return ScaleBar::qt_cast( clname );
}

bool VCScaleBar::qt_invoke( int _id, QUObject* _o )
{
    return ScaleBar::qt_invoke(_id,_o);
}

bool VCScaleBar::qt_emit( int _id, QUObject* _o )
{
    return ScaleBar::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool VCScaleBar::qt_property( int id, int f, QVariant* v)
{
    return ScaleBar::qt_property( id, f, v);
}

bool VCScaleBar::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
