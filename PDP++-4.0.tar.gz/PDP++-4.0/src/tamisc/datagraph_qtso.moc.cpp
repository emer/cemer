/****************************************************************************
** iGraphButton meta object code from reading C++ file 'datagraph_qtso.h'
**
** Created: Tue Jan 10 18:11:32 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "datagraph_qtso.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iGraphButton::className() const
{
    return "iGraphButton";
}

QMetaObject *iGraphButton::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iGraphButton( "iGraphButton", &iGraphButton::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iGraphButton::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGraphButton", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iGraphButton::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGraphButton", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iGraphButton::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "on", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"chkShow_toggled", 1, param_slot_0 };
    static const QUMethod slot_1 = {"btnAxis_pressed", 0, 0 };
    static const QUMethod slot_2 = {"btnLine_pressed", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "chkShow_toggled(bool)", &slot_0, QMetaData::Public },
	{ "btnAxis_pressed()", &slot_1, QMetaData::Public },
	{ "btnLine_pressed()", &slot_2, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iGraphButton", parentObject,
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iGraphButton.setMetaObject( metaObj );
    return metaObj;
}

void* iGraphButton::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iGraphButton" ) )
	return this;
    return QWidget::qt_cast( clname );
}

bool iGraphButton::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: chkShow_toggled((bool)static_QUType_bool.get(_o+1)); break;
    case 1: btnAxis_pressed(); break;
    case 2: btnLine_pressed(); break;
    default:
	return QWidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iGraphButton::qt_emit( int _id, QUObject* _o )
{
    return QWidget::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iGraphButton::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool iGraphButton::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iGraphButtons::className() const
{
    return "iGraphButtons";
}

QMetaObject *iGraphButtons::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iGraphButtons( "iGraphButtons", &iGraphButtons::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iGraphButtons::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGraphButtons", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iGraphButtons::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iGraphButtons", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iGraphButtons::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iGraphButtons", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iGraphButtons.setMetaObject( metaObj );
    return metaObj;
}

void* iGraphButtons::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iGraphButtons" ) )
	return this;
    return QWidget::qt_cast( clname );
}

bool iGraphButtons::qt_invoke( int _id, QUObject* _o )
{
    return QWidget::qt_invoke(_id,_o);
}

bool iGraphButtons::qt_emit( int _id, QUObject* _o )
{
    return QWidget::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iGraphButtons::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool iGraphButtons::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
