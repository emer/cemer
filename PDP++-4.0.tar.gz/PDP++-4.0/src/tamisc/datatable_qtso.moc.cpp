/****************************************************************************
** iDataTable meta object code from reading C++ file 'datatable_qtso.h'
**
** Created: Tue Jan 10 17:08:33 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "datatable_qtso.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iDataTable::className() const
{
    return "iDataTable";
}

QMetaObject *iDataTable::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iDataTable( "iDataTable", &iDataTable::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iDataTable::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataTable", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iDataTable::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataTable", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iDataTable::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QTable::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iDataTable", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iDataTable.setMetaObject( metaObj );
    return metaObj;
}

void* iDataTable::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iDataTable" ) )
	return this;
    return QTable::qt_cast( clname );
}

bool iDataTable::qt_invoke( int _id, QUObject* _o )
{
    return QTable::qt_invoke(_id,_o);
}

bool iDataTable::qt_emit( int _id, QUObject* _o )
{
    return QTable::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iDataTable::qt_property( int id, int f, QVariant* v)
{
    return QTable::qt_property( id, f, v);
}

bool iDataTable::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iDataTablePanel::className() const
{
    return "iDataTablePanel";
}

QMetaObject *iDataTablePanel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iDataTablePanel( "iDataTablePanel", &iDataTablePanel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iDataTablePanel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataTablePanel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iDataTablePanel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataTablePanel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iDataTablePanel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iDataPanelFrame::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iDataTablePanel", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iDataTablePanel.setMetaObject( metaObj );
    return metaObj;
}

void* iDataTablePanel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iDataTablePanel" ) )
	return this;
    return iDataPanelFrame::qt_cast( clname );
}

bool iDataTablePanel::qt_invoke( int _id, QUObject* _o )
{
    return iDataPanelFrame::qt_invoke(_id,_o);
}

bool iDataTablePanel::qt_emit( int _id, QUObject* _o )
{
    return iDataPanelFrame::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iDataTablePanel::qt_property( int id, int f, QVariant* v)
{
    return iDataPanelFrame::qt_property( id, f, v);
}

bool iDataTablePanel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
