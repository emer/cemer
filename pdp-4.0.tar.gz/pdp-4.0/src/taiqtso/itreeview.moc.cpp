/****************************************************************************
** iTreeView meta object code from reading C++ file 'itreeview.h'
**
** Created: Fri Nov 18 19:46:18 2005
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "itreeview.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iTreeView::className() const
{
    return "iTreeView";
}

QMetaObject *iTreeView::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iTreeView( "iTreeView", &iTreeView::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iTreeView::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTreeView", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iTreeView::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTreeView", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iTreeView::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QListView::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_0 = {"selectionChanged", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_1 = {"currentChanged", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_2 = {"clicked", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pnt", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_3 = {"clicked", 3, param_slot_3 };
    static const QUParameter param_slot_4[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_4 = {"pressed", 1, param_slot_4 };
    static const QUParameter param_slot_5[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pnt", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_5 = {"pressed", 3, param_slot_5 };
    static const QUParameter param_slot_6[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pnt", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_6 = {"doubleClicked", 3, param_slot_6 };
    static const QUParameter param_slot_7[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_7 = {"returnPressed", 1, param_slot_7 };
    static const QUParameter param_slot_8[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_8 = {"spacePressed", 1, param_slot_8 };
    static const QUParameter param_slot_9[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pnt", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_9 = {"rightButtonClicked", 3, param_slot_9 };
    static const QUParameter param_slot_10[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pnt", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_10 = {"rightButtonPressed", 3, param_slot_10 };
    static const QUParameter param_slot_11[] = {
	{ "button", &static_QUType_int, 0, QUParameter::In },
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_11 = {"mouseButtonPressed", 4, param_slot_11 };
    static const QUParameter param_slot_12[] = {
	{ "button", &static_QUType_int, 0, QUParameter::In },
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_12 = {"mouseButtonClicked", 4, param_slot_12 };
    static const QUParameter param_slot_13[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_13 = {"contextMenuRequested", 3, param_slot_13 };
    static const QUParameter param_slot_14[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_14 = {"onItem", 1, param_slot_14 };
    static const QUParameter param_slot_15[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_15 = {"expanded", 1, param_slot_15 };
    static const QUParameter param_slot_16[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_16 = {"collapsed", 1, param_slot_16 };
    static const QUParameter param_slot_17[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In },
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_17 = {"itemRenamed", 3, param_slot_17 };
    static const QUParameter param_slot_18[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_18 = {"itemRenamed", 2, param_slot_18 };
    static const QMetaData slot_tbl[] = {
	{ "selectionChanged(QListViewItem*)", &slot_0, QMetaData::Protected },
	{ "currentChanged(QListViewItem*)", &slot_1, QMetaData::Protected },
	{ "clicked(QListViewItem*)", &slot_2, QMetaData::Protected },
	{ "clicked(QListViewItem*,const QPoint&,int)", &slot_3, QMetaData::Protected },
	{ "pressed(QListViewItem*)", &slot_4, QMetaData::Protected },
	{ "pressed(QListViewItem*,const QPoint&,int)", &slot_5, QMetaData::Protected },
	{ "doubleClicked(QListViewItem*,const QPoint&,int)", &slot_6, QMetaData::Protected },
	{ "returnPressed(QListViewItem*)", &slot_7, QMetaData::Protected },
	{ "spacePressed(QListViewItem*)", &slot_8, QMetaData::Protected },
	{ "rightButtonClicked(QListViewItem*,const QPoint&,int)", &slot_9, QMetaData::Protected },
	{ "rightButtonPressed(QListViewItem*,const QPoint&,int)", &slot_10, QMetaData::Protected },
	{ "mouseButtonPressed(int,QListViewItem*,const QPoint&,int)", &slot_11, QMetaData::Protected },
	{ "mouseButtonClicked(int,QListViewItem*,const QPoint&,int)", &slot_12, QMetaData::Protected },
	{ "contextMenuRequested(QListViewItem*,const QPoint&,int)", &slot_13, QMetaData::Protected },
	{ "onItem(QListViewItem*)", &slot_14, QMetaData::Protected },
	{ "expanded(QListViewItem*)", &slot_15, QMetaData::Protected },
	{ "collapsed(QListViewItem*)", &slot_16, QMetaData::Protected },
	{ "itemRenamed(QListViewItem*,int,const QString&)", &slot_17, QMetaData::Protected },
	{ "itemRenamed(QListViewItem*,int)", &slot_18, QMetaData::Protected }
    };
    static const QUParameter param_signal_0[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In }
    };
    static const QUMethod signal_0 = {"selectionChanged", 1, param_signal_0 };
    static const QUParameter param_signal_1[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In }
    };
    static const QUMethod signal_1 = {"currentChanged", 1, param_signal_1 };
    static const QUParameter param_signal_2[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In }
    };
    static const QUMethod signal_2 = {"clicked", 1, param_signal_2 };
    static const QUParameter param_signal_3[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ "pnt", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_3 = {"clicked", 3, param_signal_3 };
    static const QUParameter param_signal_4[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In }
    };
    static const QUMethod signal_4 = {"pressed", 1, param_signal_4 };
    static const QUParameter param_signal_5[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ "pnt", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_5 = {"pressed", 3, param_signal_5 };
    static const QUParameter param_signal_6[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ 0, &static_QUType_varptr, "\x0e", QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_6 = {"doubleClicked", 3, param_signal_6 };
    static const QUParameter param_signal_7[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In }
    };
    static const QUMethod signal_7 = {"returnPressed", 1, param_signal_7 };
    static const QUParameter param_signal_8[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In }
    };
    static const QUMethod signal_8 = {"spacePressed", 1, param_signal_8 };
    static const QUParameter param_signal_9[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ 0, &static_QUType_varptr, "\x0e", QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_9 = {"rightButtonClicked", 3, param_signal_9 };
    static const QUParameter param_signal_10[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ 0, &static_QUType_varptr, "\x0e", QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_10 = {"rightButtonPressed", 3, param_signal_10 };
    static const QUParameter param_signal_11[] = {
	{ "button", &static_QUType_int, 0, QUParameter::In },
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_11 = {"mouseButtonPressed", 4, param_signal_11 };
    static const QUParameter param_signal_12[] = {
	{ "button", &static_QUType_int, 0, QUParameter::In },
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "c", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_12 = {"mouseButtonClicked", 4, param_signal_12 };
    static const QUParameter param_signal_13[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_13 = {"contextMenuRequested", 3, param_signal_13 };
    static const QUParameter param_signal_14[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In }
    };
    static const QUMethod signal_14 = {"onItem", 1, param_signal_14 };
    static const QUParameter param_signal_15[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In }
    };
    static const QUMethod signal_15 = {"expanded", 1, param_signal_15 };
    static const QUParameter param_signal_16[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In }
    };
    static const QUMethod signal_16 = {"collapsed", 1, param_signal_16 };
    static const QUParameter param_signal_17[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In },
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod signal_17 = {"itemRenamed", 3, param_signal_17 };
    static const QUParameter param_signal_18[] = {
	{ "item", &static_QUType_ptr, "iTreeViewItem", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_18 = {"itemRenamed", 2, param_signal_18 };
    static const QMetaData signal_tbl[] = {
	{ "selectionChanged(iTreeViewItem*)", &signal_0, QMetaData::Public },
	{ "currentChanged(iTreeViewItem*)", &signal_1, QMetaData::Public },
	{ "clicked(iTreeViewItem*)", &signal_2, QMetaData::Public },
	{ "clicked(iTreeViewItem*,const QPoint&,int)", &signal_3, QMetaData::Public },
	{ "pressed(iTreeViewItem*)", &signal_4, QMetaData::Public },
	{ "pressed(iTreeViewItem*,const QPoint&,int)", &signal_5, QMetaData::Public },
	{ "doubleClicked(iTreeViewItem*,const QPoint&,int)", &signal_6, QMetaData::Public },
	{ "returnPressed(iTreeViewItem*)", &signal_7, QMetaData::Public },
	{ "spacePressed(iTreeViewItem*)", &signal_8, QMetaData::Public },
	{ "rightButtonClicked(iTreeViewItem*,const QPoint&,int)", &signal_9, QMetaData::Public },
	{ "rightButtonPressed(iTreeViewItem*,const QPoint&,int)", &signal_10, QMetaData::Public },
	{ "mouseButtonPressed(int,iTreeViewItem*,const QPoint&,int)", &signal_11, QMetaData::Public },
	{ "mouseButtonClicked(int,iTreeViewItem*,const QPoint&,int)", &signal_12, QMetaData::Public },
	{ "contextMenuRequested(iTreeViewItem*,const QPoint&,int)", &signal_13, QMetaData::Public },
	{ "onItem(iTreeViewItem*)", &signal_14, QMetaData::Public },
	{ "expanded(iTreeViewItem*)", &signal_15, QMetaData::Public },
	{ "collapsed(iTreeViewItem*)", &signal_16, QMetaData::Public },
	{ "itemRenamed(iTreeViewItem*,int,const QString&)", &signal_17, QMetaData::Public },
	{ "itemRenamed(iTreeViewItem*,int)", &signal_18, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iTreeView", parentObject,
	slot_tbl, 19,
	signal_tbl, 19,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iTreeView.setMetaObject( metaObj );
    return metaObj;
}

void* iTreeView::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iTreeView" ) )
	return this;
    return QListView::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL selectionChanged
void iTreeView::selectionChanged( iTreeViewItem* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL currentChanged
void iTreeView::currentChanged( iTreeViewItem* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 1 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL clicked
void iTreeView::clicked( iTreeViewItem* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 2 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL clicked
void iTreeView::clicked( iTreeViewItem* t0, const QPoint& t1, int t2 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 3 );
    if ( !clist )
	return;
    QUObject o[4];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_varptr.set(o+2,&t1);
    static_QUType_int.set(o+3,t2);
    activate_signal( clist, o );
}

// SIGNAL pressed
void iTreeView::pressed( iTreeViewItem* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 4 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL pressed
void iTreeView::pressed( iTreeViewItem* t0, const QPoint& t1, int t2 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 5 );
    if ( !clist )
	return;
    QUObject o[4];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_varptr.set(o+2,&t1);
    static_QUType_int.set(o+3,t2);
    activate_signal( clist, o );
}

// SIGNAL doubleClicked
void iTreeView::doubleClicked( iTreeViewItem* t0, const QPoint& t1, int t2 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 6 );
    if ( !clist )
	return;
    QUObject o[4];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_varptr.set(o+2,&t1);
    static_QUType_int.set(o+3,t2);
    activate_signal( clist, o );
}

// SIGNAL returnPressed
void iTreeView::returnPressed( iTreeViewItem* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 7 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL spacePressed
void iTreeView::spacePressed( iTreeViewItem* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 8 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL rightButtonClicked
void iTreeView::rightButtonClicked( iTreeViewItem* t0, const QPoint& t1, int t2 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 9 );
    if ( !clist )
	return;
    QUObject o[4];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_varptr.set(o+2,&t1);
    static_QUType_int.set(o+3,t2);
    activate_signal( clist, o );
}

// SIGNAL rightButtonPressed
void iTreeView::rightButtonPressed( iTreeViewItem* t0, const QPoint& t1, int t2 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 10 );
    if ( !clist )
	return;
    QUObject o[4];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_varptr.set(o+2,&t1);
    static_QUType_int.set(o+3,t2);
    activate_signal( clist, o );
}

// SIGNAL mouseButtonPressed
void iTreeView::mouseButtonPressed( int t0, iTreeViewItem* t1, const QPoint& t2, int t3 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 11 );
    if ( !clist )
	return;
    QUObject o[5];
    static_QUType_int.set(o+1,t0);
    static_QUType_ptr.set(o+2,t1);
    static_QUType_varptr.set(o+3,&t2);
    static_QUType_int.set(o+4,t3);
    activate_signal( clist, o );
}

// SIGNAL mouseButtonClicked
void iTreeView::mouseButtonClicked( int t0, iTreeViewItem* t1, const QPoint& t2, int t3 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 12 );
    if ( !clist )
	return;
    QUObject o[5];
    static_QUType_int.set(o+1,t0);
    static_QUType_ptr.set(o+2,t1);
    static_QUType_varptr.set(o+3,&t2);
    static_QUType_int.set(o+4,t3);
    activate_signal( clist, o );
}

// SIGNAL contextMenuRequested
void iTreeView::contextMenuRequested( iTreeViewItem* t0, const QPoint& t1, int t2 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 13 );
    if ( !clist )
	return;
    QUObject o[4];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_varptr.set(o+2,&t1);
    static_QUType_int.set(o+3,t2);
    activate_signal( clist, o );
}

// SIGNAL onItem
void iTreeView::onItem( iTreeViewItem* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 14 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL expanded
void iTreeView::expanded( iTreeViewItem* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 15 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL collapsed
void iTreeView::collapsed( iTreeViewItem* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 16 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL itemRenamed
void iTreeView::itemRenamed( iTreeViewItem* t0, int t1, const QString& t2 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 17 );
    if ( !clist )
	return;
    QUObject o[4];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_int.set(o+2,t1);
    static_QUType_QString.set(o+3,t2);
    activate_signal( clist, o );
}

// SIGNAL itemRenamed
void iTreeView::itemRenamed( iTreeViewItem* t0, int t1 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 18 );
    if ( !clist )
	return;
    QUObject o[3];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_int.set(o+2,t1);
    activate_signal( clist, o );
}

bool iTreeView::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: selectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 1: currentChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 2: clicked((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 3: clicked((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 4: pressed((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 5: pressed((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 6: doubleClicked((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 7: returnPressed((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 8: spacePressed((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 9: rightButtonClicked((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 10: rightButtonPressed((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 11: mouseButtonPressed((int)static_QUType_int.get(_o+1),(QListViewItem*)static_QUType_ptr.get(_o+2),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+3)),(int)static_QUType_int.get(_o+4)); break;
    case 12: mouseButtonClicked((int)static_QUType_int.get(_o+1),(QListViewItem*)static_QUType_ptr.get(_o+2),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+3)),(int)static_QUType_int.get(_o+4)); break;
    case 13: contextMenuRequested((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 14: onItem((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 15: expanded((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 16: collapsed((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 17: itemRenamed((QListViewItem*)static_QUType_ptr.get(_o+1),(int)static_QUType_int.get(_o+2),(const QString&)static_QUType_QString.get(_o+3)); break;
    case 18: itemRenamed((QListViewItem*)static_QUType_ptr.get(_o+1),(int)static_QUType_int.get(_o+2)); break;
    default:
	return QListView::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iTreeView::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: selectionChanged((iTreeViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 1: currentChanged((iTreeViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 2: clicked((iTreeViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 3: clicked((iTreeViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 4: pressed((iTreeViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 5: pressed((iTreeViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 6: doubleClicked((iTreeViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 7: returnPressed((iTreeViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 8: spacePressed((iTreeViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 9: rightButtonClicked((iTreeViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 10: rightButtonPressed((iTreeViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 11: mouseButtonPressed((int)static_QUType_int.get(_o+1),(iTreeViewItem*)static_QUType_ptr.get(_o+2),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+3)),(int)static_QUType_int.get(_o+4)); break;
    case 12: mouseButtonClicked((int)static_QUType_int.get(_o+1),(iTreeViewItem*)static_QUType_ptr.get(_o+2),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+3)),(int)static_QUType_int.get(_o+4)); break;
    case 13: contextMenuRequested((iTreeViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 14: onItem((iTreeViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 15: expanded((iTreeViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 16: collapsed((iTreeViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 17: itemRenamed((iTreeViewItem*)static_QUType_ptr.get(_o+1),(int)static_QUType_int.get(_o+2),(const QString&)static_QUType_QString.get(_o+3)); break;
    case 18: itemRenamed((iTreeViewItem*)static_QUType_ptr.get(_o+1),(int)static_QUType_int.get(_o+2)); break;
    default:
	return QListView::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool iTreeView::qt_property( int id, int f, QVariant* v)
{
    return QListView::qt_property( id, f, v);
}

bool iTreeView::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
