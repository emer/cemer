/****************************************************************************
** NetViewAdapter meta object code from reading C++ file 'netstru_qtso.h'
**
** Created: Fri Nov 18 19:47:05 2005
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "netstru_qtso.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *NetViewAdapter::className() const
{
    return "NetViewAdapter";
}

QMetaObject *NetViewAdapter::metaObj = 0;
static QMetaObjectCleanUp cleanUp_NetViewAdapter( "NetViewAdapter", &NetViewAdapter::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString NetViewAdapter::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "NetViewAdapter", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString NetViewAdapter::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "NetViewAdapter", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* NetViewAdapter::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = taBaseAdapter::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "sels", &static_QUType_ptr, "ISelectable_PtrList", QUParameter::InOut }
    };
    static const QUMethod slot_0 = {"viewWin_selectionChanged", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "viewWin_selectionChanged(ISelectable_PtrList&)", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"NetViewAdapter", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_NetViewAdapter.setMetaObject( metaObj );
    return metaObj;
}

void* NetViewAdapter::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "NetViewAdapter" ) )
	return this;
    return taBaseAdapter::qt_cast( clname );
}

bool NetViewAdapter::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: viewWin_selectionChanged((ISelectable_PtrList&)*((ISelectable_PtrList*)static_QUType_ptr.get(_o+1))); break;
    default:
	return taBaseAdapter::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool NetViewAdapter::qt_emit( int _id, QUObject* _o )
{
    return taBaseAdapter::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool NetViewAdapter::qt_property( int id, int f, QVariant* v)
{
    return taBaseAdapter::qt_property( id, f, v);
}

bool NetViewAdapter::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *NetViewPanel::className() const
{
    return "NetViewPanel";
}

QMetaObject *NetViewPanel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_NetViewPanel( "NetViewPanel", &NetViewPanel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString NetViewPanel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "NetViewPanel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString NetViewPanel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "NetViewPanel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* NetViewPanel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iViewPanelFrame::staticMetaObject();
    static const QUMethod slot_0 = {"butBuildAll_pressed", 0, 0 };
    static const QUMethod slot_1 = {"butConnectAll_pressed", 0, 0 };
    static const QUMethod slot_2 = {"butNewLayer_pressed", 0, 0 };
    static const QUMethod slot_3 = {"butScaleDefault_pressed", 0, 0 };
    static const QUParameter param_slot_4[] = {
	{ "on", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_4 = {"chkAutoScale_toggled", 1, param_slot_4 };
    static const QUParameter param_slot_5[] = {
	{ "on", &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_5 = {"chkDisplay_toggled", 1, param_slot_5 };
    static const QUParameter param_slot_6[] = {
	{ "itm", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_6 = {"cmbUnitText_itemChanged", 1, param_slot_6 };
    static const QUParameter param_slot_7[] = {
	{ "itm", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_7 = {"cmbDispMode_itemChanged", 1, param_slot_7 };
    static const QUMethod slot_8 = {"cbar_scaleValueChanged", 0, 0 };
    static const QUMethod slot_9 = {"lvDisplayValues_selectionChanged", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "butBuildAll_pressed()", &slot_0, QMetaData::Protected },
	{ "butConnectAll_pressed()", &slot_1, QMetaData::Protected },
	{ "butNewLayer_pressed()", &slot_2, QMetaData::Protected },
	{ "butScaleDefault_pressed()", &slot_3, QMetaData::Protected },
	{ "chkAutoScale_toggled(bool)", &slot_4, QMetaData::Protected },
	{ "chkDisplay_toggled(bool)", &slot_5, QMetaData::Protected },
	{ "cmbUnitText_itemChanged(int)", &slot_6, QMetaData::Protected },
	{ "cmbDispMode_itemChanged(int)", &slot_7, QMetaData::Protected },
	{ "cbar_scaleValueChanged()", &slot_8, QMetaData::Protected },
	{ "lvDisplayValues_selectionChanged()", &slot_9, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"NetViewPanel", parentObject,
	slot_tbl, 10,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_NetViewPanel.setMetaObject( metaObj );
    return metaObj;
}

void* NetViewPanel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "NetViewPanel" ) )
	return this;
    return iViewPanelFrame::qt_cast( clname );
}

bool NetViewPanel::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: butBuildAll_pressed(); break;
    case 1: butConnectAll_pressed(); break;
    case 2: butNewLayer_pressed(); break;
    case 3: butScaleDefault_pressed(); break;
    case 4: chkAutoScale_toggled((bool)static_QUType_bool.get(_o+1)); break;
    case 5: chkDisplay_toggled((bool)static_QUType_bool.get(_o+1)); break;
    case 6: cmbUnitText_itemChanged((int)static_QUType_int.get(_o+1)); break;
    case 7: cmbDispMode_itemChanged((int)static_QUType_int.get(_o+1)); break;
    case 8: cbar_scaleValueChanged(); break;
    case 9: lvDisplayValues_selectionChanged(); break;
    default:
	return iViewPanelFrame::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool NetViewPanel::qt_emit( int _id, QUObject* _o )
{
    return iViewPanelFrame::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool NetViewPanel::qt_property( int id, int f, QVariant* v)
{
    return iViewPanelFrame::qt_property( id, f, v);
}

bool NetViewPanel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
