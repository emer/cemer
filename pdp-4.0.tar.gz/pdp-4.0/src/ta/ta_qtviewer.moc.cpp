/****************************************************************************
** DataLink_QObj meta object code from reading C++ file 'ta_qtviewer.h'
**
** Created: Fri Nov 18 19:46:30 2005
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ta_qtviewer.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *DataLink_QObj::className() const
{
    return "DataLink_QObj";
}

QMetaObject *DataLink_QObj::metaObj = 0;
static QMetaObjectCleanUp cleanUp_DataLink_QObj( "DataLink_QObj", &DataLink_QObj::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString DataLink_QObj::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DataLink_QObj", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString DataLink_QObj::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DataLink_QObj", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* DataLink_QObj::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QObject::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"DataLink_QObj", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_DataLink_QObj.setMetaObject( metaObj );
    return metaObj;
}

void* DataLink_QObj::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "DataLink_QObj" ) )
	return this;
    return QObject::qt_cast( clname );
}

bool DataLink_QObj::qt_invoke( int _id, QUObject* _o )
{
    return QObject::qt_invoke(_id,_o);
}

bool DataLink_QObj::qt_emit( int _id, QUObject* _o )
{
    return QObject::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool DataLink_QObj::qt_property( int id, int f, QVariant* v)
{
    return QObject::qt_property( id, f, v);
}

bool DataLink_QObj::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iDataViewer::className() const
{
    return "iDataViewer";
}

QMetaObject *iDataViewer::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iDataViewer( "iDataViewer", &iDataViewer::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iDataViewer::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataViewer", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iDataViewer::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataViewer", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iDataViewer::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QMainWindow::staticMetaObject();
    static const QUMethod slot_0 = {"fileNew", 0, 0 };
    static const QUMethod slot_1 = {"fileOpen", 0, 0 };
    static const QUMethod slot_2 = {"fileSave", 0, 0 };
    static const QUMethod slot_3 = {"fileSaveAs", 0, 0 };
    static const QUMethod slot_4 = {"fileClose", 0, 0 };
    static const QUMethod slot_5 = {"filePrint", 0, 0 };
    static const QUMethod slot_6 = {"fileCloseWindow", 0, 0 };
    static const QUMethod slot_7 = {"viewRefresh", 0, 0 };
    static const QUMethod slot_8 = {"helpAbout", 0, 0 };
    static const QUParameter param_slot_9[] = {
	{ "mel", &static_QUType_ptr, "taiMenuEl", QUParameter::In }
    };
    static const QUMethod slot_9 = {"mnuEditAction", 1, param_slot_9 };
    static const QUParameter param_slot_10[] = {
	{ "idx", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_10 = {"mnuDynAction", 1, param_slot_10 };
    static const QUMethod slot_11 = {"actionsMenu_aboutToShow", 0, 0 };
    static const QUMethod slot_12 = {"UpdateUi", 0, 0 };
    static const QUMethod slot_13 = {"ch_destroyed", 0, 0 };
    static const QUParameter param_slot_14[] = {
	{ "ea", &static_QUType_int, 0, QUParameter::InOut }
    };
    static const QUMethod slot_14 = {"this_GetEditActionsEnabled", 1, param_slot_14 };
    static const QUParameter param_slot_15[] = {
	{ "param", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_15 = {"this_EditAction", 1, param_slot_15 };
    static const QUMethod slot_16 = {"this_SetActionsEnabled", 0, 0 };
    static const QUParameter param_slot_17[] = {
	{ "param", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_17 = {"this_ToolBarSelect", 1, param_slot_17 };
    static const QMetaData slot_tbl[] = {
	{ "fileNew()", &slot_0, QMetaData::Public },
	{ "fileOpen()", &slot_1, QMetaData::Public },
	{ "fileSave()", &slot_2, QMetaData::Public },
	{ "fileSaveAs()", &slot_3, QMetaData::Public },
	{ "fileClose()", &slot_4, QMetaData::Public },
	{ "filePrint()", &slot_5, QMetaData::Public },
	{ "fileCloseWindow()", &slot_6, QMetaData::Public },
	{ "viewRefresh()", &slot_7, QMetaData::Public },
	{ "helpAbout()", &slot_8, QMetaData::Public },
	{ "mnuEditAction(taiMenuEl*)", &slot_9, QMetaData::Public },
	{ "mnuDynAction(int)", &slot_10, QMetaData::Public },
	{ "actionsMenu_aboutToShow()", &slot_11, QMetaData::Public },
	{ "UpdateUi()", &slot_12, QMetaData::Public },
	{ "ch_destroyed()", &slot_13, QMetaData::Protected },
	{ "this_GetEditActionsEnabled(int&)", &slot_14, QMetaData::Protected },
	{ "this_EditAction(int)", &slot_15, QMetaData::Protected },
	{ "this_SetActionsEnabled()", &slot_16, QMetaData::Protected },
	{ "this_ToolBarSelect(int)", &slot_17, QMetaData::Protected }
    };
    static const QUParameter param_signal_0[] = {
	{ "ea", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"EditAction", 1, param_signal_0 };
    static const QUParameter param_signal_1[] = {
	{ "ea", &static_QUType_int, 0, QUParameter::InOut }
    };
    static const QUMethod signal_1 = {"GetEditActionsEnabled", 1, param_signal_1 };
    static const QUMethod signal_2 = {"SetActionsEnabled", 0, 0 };
    static const QUParameter param_signal_3[] = {
	{ "sels", &static_QUType_ptr, "ISelectable_PtrList", QUParameter::InOut }
    };
    static const QUMethod signal_3 = {"selectionChanged", 1, param_signal_3 };
    static const QMetaData signal_tbl[] = {
	{ "EditAction(int)", &signal_0, QMetaData::Public },
	{ "GetEditActionsEnabled(int&)", &signal_1, QMetaData::Public },
	{ "SetActionsEnabled()", &signal_2, QMetaData::Public },
	{ "selectionChanged(ISelectable_PtrList&)", &signal_3, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iDataViewer", parentObject,
	slot_tbl, 18,
	signal_tbl, 4,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iDataViewer.setMetaObject( metaObj );
    return metaObj;
}

void* iDataViewer::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iDataViewer" ) )
	return this;
    if ( !qstrcmp( clname, "IDataViewHost" ) )
	return (IDataViewHost*)this;
    return QMainWindow::qt_cast( clname );
}

// SIGNAL EditAction
void iDataViewer::EditAction( int t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 0, t0 );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL GetEditActionsEnabled
void iDataViewer::GetEditActionsEnabled( int& t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 1 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_int.set(o+1,t0);
    activate_signal( clist, o );
    t0 = static_QUType_int.get(o+1);
}

// SIGNAL SetActionsEnabled
void iDataViewer::SetActionsEnabled()
{
    activate_signal( staticMetaObject()->signalOffset() + 2 );
}

// SIGNAL selectionChanged
void iDataViewer::selectionChanged( ISelectable_PtrList& t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 3 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

bool iDataViewer::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: fileNew(); break;
    case 1: fileOpen(); break;
    case 2: fileSave(); break;
    case 3: fileSaveAs(); break;
    case 4: fileClose(); break;
    case 5: filePrint(); break;
    case 6: fileCloseWindow(); break;
    case 7: viewRefresh(); break;
    case 8: helpAbout(); break;
    case 9: mnuEditAction((taiMenuEl*)static_QUType_ptr.get(_o+1)); break;
    case 10: mnuDynAction((int)static_QUType_int.get(_o+1)); break;
    case 11: actionsMenu_aboutToShow(); break;
    case 12: UpdateUi(); break;
    case 13: ch_destroyed(); break;
    case 14: this_GetEditActionsEnabled((int&)static_QUType_int.get(_o+1)); break;
    case 15: this_EditAction((int)static_QUType_int.get(_o+1)); break;
    case 16: this_SetActionsEnabled(); break;
    case 17: this_ToolBarSelect((int)static_QUType_int.get(_o+1)); break;
    default:
	return QMainWindow::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iDataViewer::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: EditAction((int)static_QUType_int.get(_o+1)); break;
    case 1: GetEditActionsEnabled((int&)static_QUType_int.get(_o+1)); break;
    case 2: SetActionsEnabled(); break;
    case 3: selectionChanged((ISelectable_PtrList&)*((ISelectable_PtrList*)static_QUType_ptr.get(_o+1))); break;
    default:
	return QMainWindow::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool iDataViewer::qt_property( int id, int f, QVariant* v)
{
    return QMainWindow::qt_property( id, f, v);
}

bool iDataViewer::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iTabDataViewer::className() const
{
    return "iTabDataViewer";
}

QMetaObject *iTabDataViewer::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iTabDataViewer( "iTabDataViewer", &iTabDataViewer::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iTabDataViewer::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTabDataViewer", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iTabDataViewer::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTabDataViewer", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iTabDataViewer::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iDataViewer::staticMetaObject();
    static const QUMethod slot_0 = {"AddTab", 0, 0 };
    static const QUMethod slot_1 = {"CloseTab", 0, 0 };
    static const QUParameter param_slot_2[] = {
	{ "forced", &static_QUType_bool, 0, QUParameter::In },
	{ "cancel", &static_QUType_bool, 0, QUParameter::InOut }
    };
    static const QUMethod slot_2 = {"Closing", 2, param_slot_2 };
    static const QUMethod slot_3 = {"viewCloseCurrentView", 0, 0 };
    static const QUMethod slot_4 = {"viewSplitVertical", 0, 0 };
    static const QUMethod slot_5 = {"viewSplitHorizontal", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "AddTab()", &slot_0, QMetaData::Public },
	{ "CloseTab()", &slot_1, QMetaData::Public },
	{ "Closing(bool,bool&)", &slot_2, QMetaData::Public },
	{ "viewCloseCurrentView()", &slot_3, QMetaData::Public },
	{ "viewSplitVertical()", &slot_4, QMetaData::Public },
	{ "viewSplitHorizontal()", &slot_5, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iTabDataViewer", parentObject,
	slot_tbl, 6,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iTabDataViewer.setMetaObject( metaObj );
    return metaObj;
}

void* iTabDataViewer::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iTabDataViewer" ) )
	return this;
    return iDataViewer::qt_cast( clname );
}

bool iTabDataViewer::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: AddTab(); break;
    case 1: CloseTab(); break;
    case 2: Closing((bool)static_QUType_bool.get(_o+1),(bool&)static_QUType_bool.get(_o+2)); break;
    case 3: viewCloseCurrentView(); break;
    case 4: viewSplitVertical(); break;
    case 5: viewSplitHorizontal(); break;
    default:
	return iDataViewer::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iTabDataViewer::qt_emit( int _id, QUObject* _o )
{
    return iDataViewer::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iTabDataViewer::qt_property( int id, int f, QVariant* v)
{
    return iDataViewer::qt_property( id, f, v);
}

bool iTabDataViewer::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iTabBar::className() const
{
    return "iTabBar";
}

QMetaObject *iTabBar::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iTabBar( "iTabBar", &iTabBar::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iTabBar::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTabBar", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iTabBar::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTabBar", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iTabBar::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QTabBar::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iTabBar", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iTabBar.setMetaObject( metaObj );
    return metaObj;
}

void* iTabBar::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iTabBar" ) )
	return this;
    return QTabBar::qt_cast( clname );
}

bool iTabBar::qt_invoke( int _id, QUObject* _o )
{
    return QTabBar::qt_invoke(_id,_o);
}

bool iTabBar::qt_emit( int _id, QUObject* _o )
{
    return QTabBar::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iTabBar::qt_property( int id, int f, QVariant* v)
{
    return QTabBar::qt_property( id, f, v);
}

bool iTabBar::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iTabView::className() const
{
    return "iTabView";
}

QMetaObject *iTabView::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iTabView( "iTabView", &iTabView::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iTabView::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTabView", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iTabView::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iTabView", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iTabView::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUMethod slot_0 = {"AddTab", 0, 0 };
    static const QUMethod slot_1 = {"CloseTab", 0, 0 };
    static const QUParameter param_slot_2[] = {
	{ "id", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"panelSelected", 1, param_slot_2 };
    static const QMetaData slot_tbl[] = {
	{ "AddTab()", &slot_0, QMetaData::Public },
	{ "CloseTab()", &slot_1, QMetaData::Public },
	{ "panelSelected(int)", &slot_2, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iTabView", parentObject,
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iTabView.setMetaObject( metaObj );
    return metaObj;
}

void* iTabView::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iTabView" ) )
	return this;
    return QWidget::qt_cast( clname );
}

bool iTabView::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: AddTab(); break;
    case 1: CloseTab(); break;
    case 2: panelSelected((int)static_QUType_int.get(_o+1)); break;
    default:
	return QWidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iTabView::qt_emit( int _id, QUObject* _o )
{
    return QWidget::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iTabView::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool iTabView::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iDataPanel::className() const
{
    return "iDataPanel";
}

QMetaObject *iDataPanel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iDataPanel( "iDataPanel", &iDataPanel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iDataPanel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataPanel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iDataPanel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataPanel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iDataPanel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QFrame::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "ea", &static_QUType_int, 0, QUParameter::InOut }
    };
    static const QUMethod slot_0 = {"this_GetEditActionsEnabled", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "param", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"this_EditAction", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "this_GetEditActionsEnabled(int&)", &slot_0, QMetaData::Protected },
	{ "this_EditAction(int)", &slot_1, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"iDataPanel", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iDataPanel.setMetaObject( metaObj );
    return metaObj;
}

void* iDataPanel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iDataPanel" ) )
	return this;
    if ( !qstrcmp( clname, "IDataLinkClient" ) )
	return (IDataLinkClient*)this;
    return QFrame::qt_cast( clname );
}

bool iDataPanel::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: this_GetEditActionsEnabled((int&)static_QUType_int.get(_o+1)); break;
    case 1: this_EditAction((int)static_QUType_int.get(_o+1)); break;
    default:
	return QFrame::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iDataPanel::qt_emit( int _id, QUObject* _o )
{
    return QFrame::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iDataPanel::qt_property( int id, int f, QVariant* v)
{
    return QFrame::qt_property( id, f, v);
}

bool iDataPanel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iDataPanelFrame::className() const
{
    return "iDataPanelFrame";
}

QMetaObject *iDataPanelFrame::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iDataPanelFrame( "iDataPanelFrame", &iDataPanelFrame::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iDataPanelFrame::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataPanelFrame", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iDataPanelFrame::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataPanelFrame", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iDataPanelFrame::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iDataPanel::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iDataPanelFrame", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iDataPanelFrame.setMetaObject( metaObj );
    return metaObj;
}

void* iDataPanelFrame::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iDataPanelFrame" ) )
	return this;
    return iDataPanel::qt_cast( clname );
}

bool iDataPanelFrame::qt_invoke( int _id, QUObject* _o )
{
    return iDataPanel::qt_invoke(_id,_o);
}

bool iDataPanelFrame::qt_emit( int _id, QUObject* _o )
{
    return iDataPanel::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iDataPanelFrame::qt_property( int id, int f, QVariant* v)
{
    return iDataPanel::qt_property( id, f, v);
}

bool iDataPanelFrame::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iViewPanelFrame::className() const
{
    return "iViewPanelFrame";
}

QMetaObject *iViewPanelFrame::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iViewPanelFrame( "iViewPanelFrame", &iViewPanelFrame::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iViewPanelFrame::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iViewPanelFrame", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iViewPanelFrame::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iViewPanelFrame", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iViewPanelFrame::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iDataPanel::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"iViewPanelFrame", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iViewPanelFrame.setMetaObject( metaObj );
    return metaObj;
}

void* iViewPanelFrame::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iViewPanelFrame" ) )
	return this;
    return iDataPanel::qt_cast( clname );
}

bool iViewPanelFrame::qt_invoke( int _id, QUObject* _o )
{
    return iDataPanel::qt_invoke(_id,_o);
}

bool iViewPanelFrame::qt_emit( int _id, QUObject* _o )
{
    return iDataPanel::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iViewPanelFrame::qt_property( int id, int f, QVariant* v)
{
    return iDataPanel::qt_property( id, f, v);
}

bool iViewPanelFrame::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iDataPanelSet::className() const
{
    return "iDataPanelSet";
}

QMetaObject *iDataPanelSet::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iDataPanelSet( "iDataPanelSet", &iDataPanelSet::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iDataPanelSet::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataPanelSet", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iDataPanelSet::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iDataPanelSet", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iDataPanelSet::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iDataPanel::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "id", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"btn_pressed", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "btn_pressed(int)", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iDataPanelSet", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iDataPanelSet.setMetaObject( metaObj );
    return metaObj;
}

void* iDataPanelSet::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iDataPanelSet" ) )
	return this;
    return iDataPanel::qt_cast( clname );
}

bool iDataPanelSet::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: btn_pressed((int)static_QUType_int.get(_o+1)); break;
    default:
	return iDataPanel::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iDataPanelSet::qt_emit( int _id, QUObject* _o )
{
    return iDataPanel::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iDataPanelSet::qt_property( int id, int f, QVariant* v)
{
    return iDataPanel::qt_property( id, f, v);
}

bool iDataPanelSet::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iListDataPanel::className() const
{
    return "iListDataPanel";
}

QMetaObject *iListDataPanel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iListDataPanel( "iListDataPanel", &iListDataPanel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iListDataPanel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iListDataPanel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iListDataPanel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iListDataPanel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iListDataPanel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iDataPanelFrame::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"list_contextMenuRequested", 3, param_slot_0 };
    static const QUMethod slot_1 = {"list_selectionChanged", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "list_contextMenuRequested(QListViewItem*,const QPoint&,int)", &slot_0, QMetaData::Protected },
	{ "list_selectionChanged()", &slot_1, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"iListDataPanel", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iListDataPanel.setMetaObject( metaObj );
    return metaObj;
}

void* iListDataPanel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iListDataPanel" ) )
	return this;
    return iDataPanelFrame::qt_cast( clname );
}

bool iListDataPanel::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: list_contextMenuRequested((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 1: list_selectionChanged(); break;
    default:
	return iDataPanelFrame::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iListDataPanel::qt_emit( int _id, QUObject* _o )
{
    return iDataPanelFrame::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iListDataPanel::qt_property( int id, int f, QVariant* v)
{
    return iDataPanelFrame::qt_property( id, f, v);
}

bool iListDataPanel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
