/****************************************************************************
** iT3ViewspaceWidget meta object code from reading C++ file 't3viewer.h'
**
** Created: Sat Nov 19 16:48:49 2005
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.4   edited Jan 21 18:14 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "t3viewer.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *iT3ViewspaceWidget::className() const
{
    return "iT3ViewspaceWidget";
}

QMetaObject *iT3ViewspaceWidget::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iT3ViewspaceWidget( "iT3ViewspaceWidget", &iT3ViewspaceWidget::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iT3ViewspaceWidget::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iT3ViewspaceWidget", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iT3ViewspaceWidget::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iT3ViewspaceWidget", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iT3ViewspaceWidget::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUParameter param_signal_0[] = {
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In }
    };
    static const QUMethod signal_0 = {"contextMenuRequested", 1, param_signal_0 };
    static const QUParameter param_signal_1[] = {
	{ "ev", &static_QUType_ptr, "iSoSelectionEvent", QUParameter::In }
    };
    static const QUMethod signal_1 = {"SoSelectionEvent", 1, param_signal_1 };
    static const QUParameter param_signal_2[] = {
	{ "sb", &static_QUType_ptr, "QScrollBar", QUParameter::In }
    };
    static const QUMethod signal_2 = {"initScrollBar", 1, param_signal_2 };
    static const QMetaData signal_tbl[] = {
	{ "contextMenuRequested(const QPoint&)", &signal_0, QMetaData::Public },
	{ "SoSelectionEvent(iSoSelectionEvent*)", &signal_1, QMetaData::Public },
	{ "initScrollBar(QScrollBar*)", &signal_2, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"iT3ViewspaceWidget", parentObject,
	0, 0,
	signal_tbl, 3,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iT3ViewspaceWidget.setMetaObject( metaObj );
    return metaObj;
}

void* iT3ViewspaceWidget::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iT3ViewspaceWidget" ) )
	return this;
    return QWidget::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL contextMenuRequested
void iT3ViewspaceWidget::contextMenuRequested( const QPoint& t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_varptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL SoSelectionEvent
void iT3ViewspaceWidget::SoSelectionEvent( iSoSelectionEvent* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 1 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL initScrollBar
void iT3ViewspaceWidget::initScrollBar( QScrollBar* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 2 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

bool iT3ViewspaceWidget::qt_invoke( int _id, QUObject* _o )
{
    return QWidget::qt_invoke(_id,_o);
}

bool iT3ViewspaceWidget::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: contextMenuRequested((const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+1))); break;
    case 1: SoSelectionEvent((iSoSelectionEvent*)static_QUType_ptr.get(_o+1)); break;
    case 2: initScrollBar((QScrollBar*)static_QUType_ptr.get(_o+1)); break;
    default:
	return QWidget::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool iT3ViewspaceWidget::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool iT3ViewspaceWidget::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *iT3DataViewer::className() const
{
    return "iT3DataViewer";
}

QMetaObject *iT3DataViewer::metaObj = 0;
static QMetaObjectCleanUp cleanUp_iT3DataViewer( "iT3DataViewer", &iT3DataViewer::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString iT3DataViewer::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iT3DataViewer", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString iT3DataViewer::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "iT3DataViewer", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* iT3DataViewer::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = iTabDataViewer::staticMetaObject();
    static const QUMethod slot_0 = {"fileExportInventor", 0, 0 };
    static const QUParameter param_slot_1[] = {
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In }
    };
    static const QUMethod slot_1 = {"vs_contextMenuRequested", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ "ev", &static_QUType_ptr, "iSoSelectionEvent", QUParameter::In }
    };
    static const QUMethod slot_2 = {"vs_SoSelectionEvent", 1, param_slot_2 };
    static const QMetaData slot_tbl[] = {
	{ "fileExportInventor()", &slot_0, QMetaData::Public },
	{ "vs_contextMenuRequested(const QPoint&)", &slot_1, QMetaData::Protected },
	{ "vs_SoSelectionEvent(iSoSelectionEvent*)", &slot_2, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"iT3DataViewer", parentObject,
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_iT3DataViewer.setMetaObject( metaObj );
    return metaObj;
}

void* iT3DataViewer::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "iT3DataViewer" ) )
	return this;
    return iTabDataViewer::qt_cast( clname );
}

bool iT3DataViewer::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: fileExportInventor(); break;
    case 1: vs_contextMenuRequested((const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+1))); break;
    case 2: vs_SoSelectionEvent((iSoSelectionEvent*)static_QUType_ptr.get(_o+1)); break;
    default:
	return iTabDataViewer::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool iT3DataViewer::qt_emit( int _id, QUObject* _o )
{
    return iTabDataViewer::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool iT3DataViewer::qt_property( int id, int f, QVariant* v)
{
    return iTabDataViewer::qt_property( id, f, v);
}

bool iT3DataViewer::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
