These projects are simply the VC8 projects with the VS version number changed.

They seem to compile fine.

To Use:

Copy VC7 folder into the place where VC8 folder is.
Open the libgsl.sln file (will open in VS.NET 2003) and build.

I have not tried to port any of the tests or examples!

Brad Aisa
baisa@colorado.edu

Mar 13, 2007